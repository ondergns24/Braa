import React, { useRef, useState } from 'react';
import { X, Camera, Trash2, Check, User } from 'lucide-react';
import { UserProfile } from '../types';

interface ProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: UserProfile;
  onUpdateAvatar: (base64: string) => Promise<void>;
}

export function ProfileModal({
  isOpen,
  onClose,
  currentUser,
  onUpdateAvatar,
}: ProfileModalProps) {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);

  if (!isOpen) return null;

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      alert('Lütfen geçerli bir resim dosyası seçin.');
      return;
    }

    setLoading(true);
    setSuccess(false);

    const reader = new FileReader();
    reader.onload = async () => {
      try {
        if (typeof reader.result === 'string') {
          await onUpdateAvatar(reader.result);
          setSuccess(true);
          setTimeout(() => setSuccess(false), 2500);
        }
      } catch (err: any) {
        alert(err.message || 'Fotoğraf güncellenemedi.');
      } finally {
        setLoading(false);
      }
    };
    reader.readAsDataURL(file);
    e.target.value = '';
  };

  const handleRemovePhoto = async () => {
    if (!currentUser.avatar) return;
    setLoading(true);
    try {
      await onUpdateAvatar('');
      setSuccess(true);
      setTimeout(() => setSuccess(false), 2500);
    } catch (err: any) {
      alert(err.message || 'Fotoğraf kaldırılamadı.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200"
      onClick={onClose}
    >
      <div
        className="w-full max-w-sm rounded-3xl bg-[#121722] border border-slate-800 shadow-2xl p-6 relative overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between mb-6 pb-3 border-b border-slate-800/80">
          <div className="flex items-center gap-2">
            <User className="w-5 h-5 text-teal-400" />
            <h2 className="text-base font-bold text-white tracking-wide">Profil Fotoğrafı</h2>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-full text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Hidden File Input */}
        <input
          ref={fileInputRef}
          type="file"
          accept="image/*"
          className="hidden"
          onChange={handleFileChange}
        />

        {/* Avatar Display & Edit Area */}
        <div className="flex flex-col items-center mb-6">
          <div className="relative group mb-4">
            <div className="w-32 h-32 rounded-full overflow-hidden bg-slate-800 border-2 border-teal-500/50 shadow-xl flex items-center justify-center">
              {currentUser.avatar ? (
                <img
                  src={currentUser.avatar}
                  alt={currentUser.username}
                  className="w-full h-full object-cover"
                />
              ) : (
                <span className="text-4xl font-extrabold text-teal-400">
                  {currentUser.username.charAt(0).toUpperCase()}
                </span>
              )}
            </div>

            {/* Quick Upload Hover Overlay */}
            <button
              type="button"
              disabled={loading}
              onClick={() => fileInputRef.current?.click()}
              className="absolute inset-0 rounded-full bg-black/60 opacity-0 group-hover:opacity-100 flex flex-col items-center justify-center text-white transition-opacity cursor-pointer disabled:cursor-not-allowed"
              title="Yeni Fotoğraf Seç"
            >
              <Camera className="w-7 h-7 mb-1 text-teal-300" />
              <span className="text-[11px] font-medium">Değiştir</span>
            </button>
          </div>

          <h3 className="text-lg font-bold text-white">{currentUser.username}</h3>
          <span className="text-xs text-slate-400 mt-0.5">
            {currentUser.role === 'SUPER_ADMIN' ? 'Süper Yönetici' : 'Kullanıcı'}
          </span>
        </div>

        {/* Success message */}
        {success && (
          <div className="mb-4 px-3 py-2 rounded-xl bg-teal-500/20 border border-teal-500/40 text-teal-300 text-xs flex items-center justify-center gap-1.5 animate-in fade-in">
            <Check className="w-4 h-4" />
            <span>Profil fotoğrafı güncellendi</span>
          </div>
        )}

        {/* Action Buttons */}
        <div className="space-y-2.5">
          <button
            type="button"
            disabled={loading}
            onClick={() => fileInputRef.current?.click()}
            className="w-full py-3 px-4 rounded-xl bg-teal-500 hover:bg-teal-400 text-slate-950 font-bold text-xs tracking-wide transition-all flex items-center justify-center gap-2 cursor-pointer shadow-lg shadow-teal-500/20 disabled:opacity-50"
          >
            <Camera className="w-4 h-4" />
            <span>{currentUser.avatar ? 'Fotoğrafı Değiştir' : 'Fotoğraf Yükle'}</span>
          </button>

          {currentUser.avatar && (
            <button
              type="button"
              disabled={loading}
              onClick={handleRemovePhoto}
              className="w-full py-2.5 px-4 rounded-xl bg-red-500/15 hover:bg-red-500/25 border border-red-500/30 text-red-300 font-medium text-xs transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
            >
              <Trash2 className="w-4 h-4" />
              <span>Fotoğrafı Kaldır</span>
            </button>
          )}

          <button
            type="button"
            onClick={onClose}
            className="w-full py-2 px-4 rounded-xl text-slate-400 hover:text-slate-200 text-xs transition-colors"
          >
            Kapat
          </button>
        </div>
      </div>
    </div>
  );
}
