import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.bra.messenger',
  appName: 'Bra',
  webDir: 'dist',
  backgroundColor: '#0b0e14',
  server: {
    androidScheme: 'https',
  },
  ios: {
    contentInset: 'never',
    backgroundColor: '#0b0e14',
  },
  android: {
    backgroundColor: '#0b0e14',
    allowMixedContent: false,
  },
};

export default config;
