import React, { useState, useRef, useEffect } from 'react';
import {
  Send,
  Mic,
  Paperclip,
  Smile,
  X,
  Image,
  Video,
  FileText,
  Square,
  Trash2,
  Lock,
} from 'lucide-react';
import { DecryptedMessage } from '../types';

interface MessageInputProps {
  onSendMessage: (text: string, replyTo?: DecryptedMessage) => void;
  onSendMedia: (file: File, type: 'image' | 'video' | 'file', replyTo?: DecryptedMessage) => Promise<void>;
  onSendVoiceNote: (audioBlob: Blob, durationSeconds: number, replyTo?: DecryptedMessage) => Promise<void>;
  onTyping: (isTyping: boolean) => void;
  replyingTo: DecryptedMessage | null;
  onCancelReply: () => void;
  disabled?: boolean;
}

const EMOJI_LIST = ['😀', '😂', '😍', '🔥', '👍', '❤️', '🙌', '🎉', '🔒', '🤐', '🛡️', '🗝️'];

export function MessageInput({
  onSendMessage,
  onSendMedia,
  onSendVoiceNote,
  onTyping,
  replyingTo,
  onCancelReply,
  disabled = false,
}: MessageInputProps) {
  const [text, setText] = useState('');
  const [showAttachMenu, setShowAttachMenu] = useState(false);
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);

  // Voice note recording states
  const [isRecording, setIsRecording] = useState(false);
  const [recordingSeconds, setRecordingSeconds] = useState(0);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const recordTimerRef = useRef<number | null>(null);

  // File input refs
  const imageInputRef = useRef<HTMLInputElement>(null);
  const videoInputRef = useRef<HTMLInputElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Typing throttling
  const typingTimeoutRef = useRef<number | null>(null);

  const handleTextChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setText(e.target.value);

    // Notify peer typing
    onTyping(true);
    if (typingTimeoutRef.current) {
      clearTimeout(typingTimeoutRef.current);
    }
    typingTimeoutRef.current = window.setTimeout(() => {
      onTyping(false);
    }, 2000);
  };

  const handleSend = () => {
    if (!text.trim() || disabled) return;
    onSendMessage(text.trim(), replyingTo || undefined);
    setText('');
    onTyping(false);
    if (replyingTo) onCancelReply();
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  // Voice Note Recording
  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;
      audioChunksRef.current = [];

      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          audioChunksRef.current.push(event.data);
        }
      };

      mediaRecorder.start();
      setIsRecording(true);
      setRecordingSeconds(0);

      recordTimerRef.current = window.setInterval(() => {
        setRecordingSeconds((prev) => prev + 1);
      }, 1000);
    } catch (err) {
      console.error('Mikrofon erişim hatası:', err);
      alert('Sesli mesaj kaydetmek için mikrofon izni gereklidir.');
    }
  };

  const stopAndSendRecording = () => {
    if (!mediaRecorderRef.current || !isRecording) return;

    if (recordTimerRef.current) {
      clearInterval(recordTimerRef.current);
      recordTimerRef.current = null;
    }

    const duration = recordingSeconds;
    mediaRecorderRef.current.onstop = async () => {
      const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
      // Stop all mic tracks
      mediaRecorderRef.current?.stream.getTracks().forEach((track) => track.stop());
      mediaRecorderRef.current = null;
      setIsRecording(false);
      setRecordingSeconds(0);

      if (duration >= 1) {
        await onSendVoiceNote(audioBlob, duration, replyingTo || undefined);
        if (replyingTo) onCancelReply();
      }
    };

    mediaRecorderRef.current.stop();
  };

  const cancelRecording = () => {
    if (!mediaRecorderRef.current) return;
    if (recordTimerRef.current) {
      clearInterval(recordTimerRef.current);
      recordTimerRef.current = null;
    }
    mediaRecorderRef.current.stream.getTracks().forEach((track) => track.stop());
    mediaRecorderRef.current = null;
    audioChunksRef.current = [];
    setIsRecording(false);
    setRecordingSeconds(0);
  };

  // File selection handlers
  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>, type: 'image' | 'video' | 'file') => {
    const file = e.target.files?.[0];
    if (!file) return;
    setShowAttachMenu(false);
    await onSendMedia(file, type, replyingTo || undefined);
    if (replyingTo) onCancelReply();
    e.target.value = ''; // Reset input
  };

  const formatSeconds = (sec: number) => {
    const m = Math.floor(sec / 60);
    const s = sec % 60;
    return `${m}:${s < 10 ? '0' : ''}${s}`;
  };

  return (
    <div className="w-full bg-[#111620] border-t border-slate-800/80 p-3 shrink-0 relative z-20">
      {/* Hidden file inputs */}
      <input
        ref={imageInputRef}
        type="file"
        accept="image/*"
        className="hidden"
        onChange={(e) => handleFileChange(e, 'image')}
      />
      <input
        ref={videoInputRef}
        type="file"
        accept="video/*"
        className="hidden"
        onChange={(e) => handleFileChange(e, 'video')}
      />
      <input
        ref={fileInputRef}
        type="file"
        accept="*/*"
        className="hidden"
        onChange={(e) => handleFileChange(e, 'file')}
      />

      {/* Quoted Reply Bar */}
      {replyingTo && (
        <div className="mb-2 p-2 rounded-xl bg-[#161f2e] border-l-4 border-teal-500 flex items-center justify-between animate-in slide-in-from-bottom-2 duration-150">
          <div className="min-w-0 pr-2">
            <div className="text-[11px] font-semibold text-teal-400">
              {replyingTo.sender} kişisine yanıt veriliyor
            </div>
            <div className="text-xs text-slate-300 truncate">
              {replyingTo.text || (replyingTo.type === 'audio' ? 'Sesli Mesaj' : 'Medya')}
            </div>
          </div>
          <button
            type="button"
            onClick={onCancelReply}
            className="p-1 rounded-md text-slate-400 hover:text-white"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Attachment Menu Popup */}
      {showAttachMenu && (
        <div className="absolute bottom-16 left-4 bg-[#141b26] border border-slate-700/80 rounded-2xl shadow-2xl p-2 min-w-44 space-y-1 animate-in zoom-in-95 duration-150 z-30">
          <button
            type="button"
            onClick={() => imageInputRef.current?.click()}
            className="w-full flex items-center gap-3 px-3 py-2 rounded-xl text-slate-200 hover:bg-slate-800 text-xs text-left"
          >
            <div className="w-7 h-7 rounded-lg bg-teal-500/20 text-teal-300 flex items-center justify-center">
              <Image className="w-4 h-4" />
            </div>
            <span>Fotoğraf Gönder</span>
          </button>

          <button
            type="button"
            onClick={() => videoInputRef.current?.click()}
            className="w-full flex items-center gap-3 px-3 py-2 rounded-xl text-slate-200 hover:bg-slate-800 text-xs text-left"
          >
            <div className="w-7 h-7 rounded-lg bg-blue-500/20 text-blue-300 flex items-center justify-center">
              <Video className="w-4 h-4" />
            </div>
            <span>Video Gönder</span>
          </button>

          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            className="w-full flex items-center gap-3 px-3 py-2 rounded-xl text-slate-200 hover:bg-slate-800 text-xs text-left"
          >
            <div className="w-7 h-7 rounded-lg bg-purple-500/20 text-purple-300 flex items-center justify-center">
              <FileText className="w-4 h-4" />
            </div>
            <span>Belge / Dosya</span>
          </button>
        </div>
      )}

      {/* Emoji Bar */}
      {showEmojiPicker && (
        <div className="mb-2 p-2 rounded-xl bg-[#161f2e] border border-slate-800 flex items-center justify-between gap-1 overflow-x-auto">
          {EMOJI_LIST.map((emoji) => (
            <button
              key={emoji}
              type="button"
              onClick={() => {
                setText((prev) => prev + emoji);
              }}
              className="text-lg p-1.5 hover:scale-125 transition-transform"
            >
              {emoji}
            </button>
          ))}
          <button
            type="button"
            onClick={() => setShowEmojiPicker(false)}
            className="text-slate-400 hover:text-slate-200 p-1"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Main Input Row */}
      {isRecording ? (
        // Voice Recording Bar
        <div className="flex items-center gap-3 bg-[#161d28] border border-red-500/40 rounded-2xl px-4 py-2.5 animate-pulse">
          <div className="w-3 h-3 rounded-full bg-red-500 animate-ping" />
          <span className="text-xs font-semibold text-red-400">Ses Kaydediliyor...</span>
          <span className="text-xs font-mono text-slate-200">{formatSeconds(recordingSeconds)}</span>

          <div className="flex-1" />

          {/* Cancel */}
          <button
            type="button"
            onClick={cancelRecording}
            className="p-2 rounded-xl text-slate-400 hover:text-red-400 hover:bg-red-500/10 transition-colors"
            title="İptal Et"
          >
            <Trash2 className="w-4 h-4" />
          </button>

          {/* Send Recording */}
          <button
            type="button"
            onClick={stopAndSendRecording}
            className="p-2 rounded-xl bg-teal-500 text-slate-950 font-bold hover:bg-teal-400 transition-colors shadow-md"
            title="Sesli Mesajı Gönder"
          >
            <Send className="w-4 h-4" />
          </button>
        </div>
      ) : (
        // Normal Typing Input Bar
        <div className="flex items-end gap-2">
          {/* Attachment Toggle */}
          <button
            type="button"
            onClick={() => setShowAttachMenu(!showAttachMenu)}
            aria-label="Dosya Ekle"
            className="p-2.5 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors border border-slate-700/60"
            title="Dosya, fotoğraf veya video ekle"
          >
            <Paperclip className="w-4 h-4" />
          </button>

          {/* Emoji Toggle */}
          <button
            type="button"
            onClick={() => setShowEmojiPicker(!showEmojiPicker)}
            aria-label="Emoji Seç"
            className="p-2.5 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors border border-slate-700/60 hidden sm:flex"
            title="Emoji seç"
          >
            <Smile className="w-4 h-4" />
          </button>

          {/* Textarea */}
          <div className="flex-1 relative bg-[#0b0e14] rounded-2xl border border-slate-700/70 focus-within:border-teal-500 transition-colors">
            <textarea
              value={text}
              onChange={handleTextChange}
              onKeyDown={handleKeyDown}
              disabled={disabled}
              placeholder="Şifreli mesaj yazın... (Enter ile gönder)"
              rows={1}
              className="w-full max-h-32 px-3.5 py-2.5 bg-transparent text-slate-100 placeholder-slate-500 text-sm focus:outline-none resize-none leading-relaxed"
            />
          </div>

          {/* Send Text or Mic Button */}
          {text.trim() ? (
            <button
              type="button"
              onClick={handleSend}
              disabled={disabled}
              aria-label="Mesajı Gönder"
              className="p-2.5 rounded-xl bg-teal-500 hover:bg-teal-400 text-slate-950 transition-all font-bold shadow-md shadow-teal-500/20 active:scale-95 shrink-0"
              title="Şifreli Gönder"
            >
              <Send className="w-4 h-4" />
            </button>
          ) : (
            <button
              type="button"
              onClick={startRecording}
              disabled={disabled}
              aria-label="Sesli Mesaj Kaydet"
              className="p-2.5 rounded-xl bg-slate-800/80 hover:bg-teal-500/20 text-slate-300 hover:text-teal-400 transition-all border border-slate-700/60 active:scale-95 shrink-0"
              title="Sesli Mesaj Kaydet"
            >
              <Mic className="w-4 h-4" />
            </button>
          )}
        </div>
      )}
    </div>
  );
}
