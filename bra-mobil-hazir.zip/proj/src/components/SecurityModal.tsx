import React, { useState, useEffect } from 'react';
import {
  X,
  ShieldCheck,
  QrCode,
  Check,
  Lock,
  Key,
  Radio,
  FileCheck2,
  Copy,
} from 'lucide-react';
import { cryptoManager } from '../crypto/clientStore';
import { UserProfile } from '../types';

interface SecurityModalProps {
  currentUser: UserProfile;
  peerUser: UserProfile;
  onClose: () => void;
}

export function SecurityModal({ currentUser, peerUser, onClose }: SecurityModalProps) {
  const [safetyNumber, setSafetyNumber] = useState<string>('Yükleniyor...');
  const [isVerified, setIsVerified] = useState<boolean>(false);
  const [copied, setCopied] = useState<boolean>(false);

  useEffect(() => {
    const loadSafety = async () => {
      const num = await cryptoManager.computeSafetyNumber();
      setSafetyNumber(num);
    };
    loadSafety();

    const storedVerification = localStorage.getItem(`aegis_verified_${peerUser.username}`);
    setIsVerified(storedVerification === 'true');
  }, [peerUser.username]);

  const toggleVerification = () => {
    const next = !isVerified;
    setIsVerified(next);
    localStorage.setItem(`aegis_verified_${peerUser.username}`, String(next));
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(safetyNumber);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-200">
      <div className="w-full max-w-lg bg-[#121722] border border-slate-800 rounded-3xl shadow-2xl overflow-hidden flex flex-col">
        {/* Header */}
        <div className="p-5 border-b border-slate-800 bg-[#0e131c] flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-teal-500/20 border border-teal-500/40 flex items-center justify-center text-teal-400">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white leading-tight">
                Güvenlik Numarası ve E2EE Doğrulaması
              </h3>
              <p className="text-xs text-slate-400">
                {peerUser.displayName || peerUser.username} ile uçtan uca şifreli oturum
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-6 overflow-y-auto max-h-[80vh]">
          {/* Explanation */}
          <p className="text-xs text-slate-300 leading-relaxed">
            Signal mimarisinde olduğu gibi, uçtan uca şifrelemenin üçüncü bir tarafça dinlenmediğini (MITM saldırısı olmadığını)
            doğrulamak için aşağıdaki 60 basamaklı güvenlik numarasını karşılaştırabilirsiniz.
          </p>

          {/* Safety Number Display */}
          <div className="p-4 rounded-2xl bg-[#0b0e15] border border-slate-800 text-center">
            <div className="text-[10px] font-bold uppercase tracking-wider text-teal-400 mb-2 flex items-center justify-center gap-1">
              <Key className="w-3.5 h-3.5" /> 60 Haneli Güvenlik Numarası
            </div>
            <div className="font-mono text-sm tracking-widest text-slate-100 font-semibold leading-relaxed py-2 break-words">
              {safetyNumber}
            </div>

            <div className="mt-3 flex items-center justify-center gap-2">
              <button
                type="button"
                onClick={handleCopy}
                className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs text-slate-300 flex items-center gap-1.5 transition-colors"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-teal-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied ? 'Kopyalandı' : 'Numarayı Kopyala'}</span>
              </button>
            </div>
          </div>

          {/* Verification Toggle */}
          <div className="flex items-center justify-between p-4 rounded-2xl bg-[#151c27] border border-slate-800">
            <div>
              <div className="text-xs font-bold text-white flex items-center gap-1.5">
                <FileCheck2 className="w-4 h-4 text-teal-400" />
                Güvenlik Numarası Doğrulandı
              </div>
              <div className="text-[11px] text-slate-400 mt-0.5">
                {peerUser.username} ile numaranın eşleştiğini onaylayın
              </div>
            </div>

            <button
              type="button"
              onClick={toggleVerification}
              className={`px-3.5 py-2 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all ${
                isVerified
                  ? 'bg-emerald-500 text-slate-950 shadow-md shadow-emerald-500/20'
                  : 'bg-slate-800 text-slate-400 hover:text-white border border-slate-700'
              }`}
            >
              {isVerified && <Check className="w-3.5 h-3.5" />}
              <span>{isVerified ? 'Doğrulandı' : 'Doğrula'}</span>
            </button>
          </div>

          {/* Cryptographic Architecture Specs */}
          <div className="p-4 rounded-2xl bg-[#0e131d] border border-slate-800 space-y-2.5">
            <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
              <Lock className="w-3.5 h-3.5 text-teal-400" /> Kriptografik Protokol Detayları
            </h4>
            <div className="grid grid-cols-2 gap-2 text-[11px]">
              <div className="p-2 rounded-lg bg-[#141b25] text-slate-400">
                <div className="text-slate-500 text-[10px]">Asimetrik Anahtar</div>
                <div className="text-slate-200 font-semibold">ECDH P-256 (secp256r1)</div>
              </div>
              <div className="p-2 rounded-lg bg-[#141b25] text-slate-400">
                <div className="text-slate-500 text-[10px]">Simetrik Şifreleme</div>
                <div className="text-slate-200 font-semibold">AES-GCM 256-bit</div>
              </div>
              <div className="p-2 rounded-lg bg-[#141b25] text-slate-400">
                <div className="text-slate-500 text-[10px]">Sesli/Görüntülü Arama</div>
                <div className="text-slate-200 font-semibold">WebRTC DTLS-SRTP</div>
              </div>
              <div className="p-2 rounded-lg bg-[#141b25] text-slate-400">
                <div className="text-slate-500 text-[10px]">Kimlik Doğrulama</div>
                <div className="text-slate-200 font-semibold">PBKDF2-HMAC-SHA512</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
