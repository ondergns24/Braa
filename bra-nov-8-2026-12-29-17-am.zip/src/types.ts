export type UserRole = 'SUPER_ADMIN' | 'NORMAL_USER';
export type Username = 'Golu' | 'Kelmiji';

export interface UserProfile {
  username: Username;
  role: UserRole;
  displayName: string;
  avatar?: string;
  publicKeyJwk?: JsonWebKey;
  lastSeen?: number;
  isOnline?: boolean;
}

export interface DecryptedMessage {
  id: string;
  sender: Username;
  recipient: Username;
  type: 'text' | 'image' | 'video' | 'audio' | 'file';
  text?: string;
  mediaUrl?: string; // Decrypted blob object URL
  mediaMimeType?: string;
  mediaName?: string;
  mediaSize?: number;
  audioDuration?: number;
  replyTo?: {
    id: string;
    sender: Username;
    textSnippet: string;
  };
  timestamp: number;
  status: 'sent' | 'delivered' | 'read';
  reactions: Record<string, string[]>;
  deletedForEveryone?: boolean;
  decryptionError?: boolean;
}

export interface ActiveSession {
  token: string;
  rawToken?: string;
  username: Username;
  role: UserRole;
  ip: string;
  deviceName: string;
  userAgent: string;
  createdAt: number;
  lastActive: number;
  isCurrent?: boolean;
}

export interface AuditLog {
  id: string;
  timestamp: number;
  event: string;
  username: string;
  ip: string;
  userAgent: string;
  status: 'SUCCESS' | 'WARNING' | 'ALERT';
  details: string;
}

export interface AppSettings {
  appName: string;
  appTitle: string;
  disappearingTimerSeconds: number;
  allowCalling: boolean;
  allowMedia: boolean;
  themeAccent: string;
  autoLockMinutes: number;
}

export interface CallState {
  isActive: boolean;
  isIncoming: boolean;
  peer: Username;
  type: 'voice' | 'video';
  status: 'idle' | 'calling' | 'ringing' | 'connected' | 'ended';
  isMuted: boolean;
  isCameraOff: boolean;
  facingMode: 'user' | 'environment';
  startedAt?: number;
}
