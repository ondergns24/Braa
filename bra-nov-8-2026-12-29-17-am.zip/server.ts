import express, { Request, Response, NextFunction } from 'express';
import http from 'node:http';
import path from 'node:path';
import fs from 'node:fs';
import { WebSocketServer, WebSocket } from 'ws';
import { createServer as createViteServer } from 'vite';
import {
  hashPassword,
  verifyPassword,
  generateSessionToken,
  generateEcKeyPairJwk,
  RateLimiter,
} from './src/utils/crypto-node.js';

const PORT = 3000;
const isDev = process.env.NODE_ENV !== 'production';

// Ensure data directory exists
const DATA_DIR = path.resolve(process.cwd(), 'data');
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}
const DB_FILE = path.join(DATA_DIR, 'aegis-db.json');

// Types
export interface UserRecord {
  username: 'Golu' | 'Kelmiji';
  role: 'SUPER_ADMIN' | 'NORMAL_USER';
  displayName: string;
  passwordHash: string;
  passwordSalt: string;
  iterations: number;
  publicKeyJwk?: any;
  privateKeyJwk?: any;
  avatar?: string;
  lastSeen: number;
  isOnline: boolean;
}

export interface SessionRecord {
  token: string;
  username: 'Golu' | 'Kelmiji';
  role: 'SUPER_ADMIN' | 'NORMAL_USER';
  ip: string;
  userAgent: string;
  deviceName: string;
  createdAt: number;
  lastActive: number;
  expiresAt: number;
}

export interface EncryptedMessageRecord {
  id: string;
  sender: 'Golu' | 'Kelmiji';
  recipient: 'Golu' | 'Kelmiji';
  ciphertext: string; // E2EE encrypted JSON payload
  iv: string; // E2EE IV
  mediaId?: string; // Optional encrypted media reference
  mediaMimeType?: string;
  mediaName?: string;
  mediaSize?: number;
  type: 'text' | 'image' | 'video' | 'audio' | 'file';
  replyToId?: string;
  timestamp: number;
  status: 'sent' | 'delivered' | 'read';
  reactions: Record<string, string[]>; // { "❤️": ["Golu"], "👍": ["Kelmiji"] }
  deletedForEveryone?: boolean;
  deletedForUsers?: string[];
}

export interface EncryptedMediaRecord {
  id: string;
  sender: 'Golu' | 'Kelmiji';
  encryptedBase64: string;
  iv: string;
  mimeType: string;
  filename: string;
  size: number;
  createdAt: number;
}

export interface AuditLogRecord {
  id: string;
  timestamp: number;
  event: 'LOGIN_SUCCESS' | 'LOGIN_FAILURE' | 'LOGOUT' | 'PASSWORD_CHANGE' | 'SESSION_REVOKED' | 'KEY_EXCHANGED' | 'MESSAGE_WIPE' | 'SETTINGS_UPDATE';
  username: string;
  ip: string;
  userAgent: string;
  status: 'SUCCESS' | 'WARNING' | 'ALERT';
  details: string;
}

export interface AppSettings {
  appName: string;
  appTitle: string;
  disappearingTimerSeconds: number; // 0 = disabled
  allowCalling: boolean;
  allowMedia: boolean;
  themeAccent: string; // e.g. 'teal' | 'emerald' | 'cyan' | 'blue'
  autoLockMinutes: number;
}

interface DatabaseSchema {
  isSetupCompleted: boolean;
  users: Record<string, UserRecord>;
  sessions: SessionRecord[];
  messages: EncryptedMessageRecord[];
  media: EncryptedMediaRecord[];
  settings: AppSettings;
  auditLogs: AuditLogRecord[];
}

// Initial Default DB State
function getInitialDb(): DatabaseSchema {
  const goluCreds = hashPassword('Ondergns24.');
  const kelmijiCreds = hashPassword('Gofık24.');
  const goluKeys = generateEcKeyPairJwk();
  const kelmijiKeys = generateEcKeyPairJwk();

  return {
    isSetupCompleted: true,
    users: {
      Golu: {
        username: 'Golu',
        role: 'SUPER_ADMIN',
        displayName: 'Golu',
        passwordHash: goluCreds.hash,
        passwordSalt: goluCreds.salt,
        iterations: goluCreds.iterations,
        publicKeyJwk: goluKeys.publicKey,
        privateKeyJwk: goluKeys.privateKey,
        avatar: '',
        lastSeen: Date.now(),
        isOnline: false,
      },
      Kelmiji: {
        username: 'Kelmiji',
        role: 'NORMAL_USER',
        displayName: 'Kelmiji',
        passwordHash: kelmijiCreds.hash,
        passwordSalt: kelmijiCreds.salt,
        iterations: kelmijiCreds.iterations,
        publicKeyJwk: kelmijiKeys.publicKey,
        privateKeyJwk: kelmijiKeys.privateKey,
        avatar: '',
        lastSeen: Date.now(),
        isOnline: false,
      },
    },
    sessions: [],
    messages: [],
    media: [],
    settings: {
      appName: 'Bra',
      appTitle: 'Bra',
      disappearingTimerSeconds: 0,
      allowCalling: true,
      allowMedia: true,
      themeAccent: 'teal',
      autoLockMinutes: 15,
    },
    auditLogs: [
      {
        id: 'init-1',
        timestamp: Date.now(),
        event: 'SETTINGS_UPDATE',
        username: 'SYSTEM',
        ip: '127.0.0.1',
        userAgent: 'Bra Engine',
        status: 'SUCCESS',
        details: 'Bra güvenli parametrelerle ve iki kullanıcıyla (Golu & Kelmiji) başlatıldı.',
      },
    ],
  };
}

// Load or Initialize DB
let db: DatabaseSchema;
try {
  if (fs.existsSync(DB_FILE)) {
    const raw = fs.readFileSync(DB_FILE, 'utf-8');
    db = JSON.parse(raw);

    // Apply requested credentials & branding
    const goluCreds = hashPassword('Ondergns24.');
    const kelmijiCreds = hashPassword('Gofık24.');
    db.users.Golu.passwordHash = goluCreds.hash;
    db.users.Golu.passwordSalt = goluCreds.salt;
    db.users.Golu.iterations = goluCreds.iterations;
    db.users.Golu.displayName = 'Golu';

    db.users.Kelmiji.passwordHash = kelmijiCreds.hash;
    db.users.Kelmiji.passwordSalt = kelmijiCreds.salt;
    db.users.Kelmiji.iterations = kelmijiCreds.iterations;
    db.users.Kelmiji.displayName = 'Kelmiji';

    db.settings.appName = 'Bra';
    db.settings.appTitle = 'Bra';

    // Ensure keys exist if DB was loaded from earlier state
    if (!db.users.Golu.publicKeyJwk || !db.users.Golu.privateKeyJwk) {
      const gKeys = generateEcKeyPairJwk();
      db.users.Golu.publicKeyJwk = gKeys.publicKey;
      db.users.Golu.privateKeyJwk = gKeys.privateKey;
    }
    if (!db.users.Kelmiji.publicKeyJwk || !db.users.Kelmiji.privateKeyJwk) {
      const kKeys = generateEcKeyPairJwk();
      db.users.Kelmiji.publicKeyJwk = kKeys.publicKey;
      db.users.Kelmiji.privateKeyJwk = kKeys.privateKey;
    }
    fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2));
  } else {
    db = getInitialDb();
    fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2));
  }
} catch {
  db = getInitialDb();
  fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2));
}

function saveDb() {
  try {
    fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2));
  } catch (err) {
    console.error('Failed to save DB:', err);
  }
}

// Rate Limiter instance (5 failed attempts, 15 min lock)
const loginLimiter = new RateLimiter(5, 15 * 60 * 1000, 15 * 60 * 1000);

// App & Server setup
const app = express();
const server = http.createServer(app);

app.use(express.json({ limit: '60mb' }));
app.use(express.urlencoded({ extended: true, limit: '60mb' }));

// Helper: Parse device name from user-agent
function parseDeviceName(ua: string): string {
  if (/iphone/i.test(ua)) return 'Apple iPhone (iOS)';
  if (/ipad/i.test(ua)) return 'Apple iPad (iPadOS)';
  if (/android/i.test(ua)) return 'Android Device';
  if (/macintosh|mac os x/i.test(ua)) return 'Apple Mac';
  if (/windows/i.test(ua)) return 'Windows PC';
  if (/linux/i.test(ua)) return 'Linux Workstation';
  return 'Mobil / Web İstemcisi';
}

// Helper: Log audit events
function logAudit(
  event: AuditLogRecord['event'],
  username: string,
  req: Request,
  status: AuditLogRecord['status'],
  details: string
) {
  const ip = (req.headers['x-forwarded-for'] as string) || req.socket.remoteAddress || '127.0.0.1';
  const userAgent = req.headers['user-agent'] || 'Bilinmeyen Tarayıcı';

  const entry: AuditLogRecord = {
    id: `log-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
    timestamp: Date.now(),
    event,
    username,
    ip: ip.split(',')[0].trim(),
    userAgent,
    status,
    details,
  };

  db.auditLogs.unshift(entry);
  if (db.auditLogs.length > 500) {
    db.auditLogs = db.auditLogs.slice(0, 500);
  }
  saveDb();
}

// Auth Middleware
export interface AuthenticatedRequest extends Request {
  user?: UserRecord;
  session?: SessionRecord;
}

function requireAuth(req: AuthenticatedRequest, res: Response, next: NextFunction) {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Oturum açmanız gerekiyor. Yetkisiz istek.' });
  }

  const token = authHeader.substring(7);
  const session = db.sessions.find((s) => s.token === token);

  if (!session) {
    return res.status(401).json({ error: 'Geçersiz veya süresi dolmuş oturum.' });
  }

  if (session.expiresAt < Date.now()) {
    // Remove expired
    db.sessions = db.sessions.filter((s) => s.token !== token);
    saveDb();
    return res.status(401).json({ error: 'Oturum süresi doldu. Lütfen tekrar giriş yapın.' });
  }

  const user = db.users[session.username];
  if (!user) {
    return res.status(401).json({ error: 'Kullanıcı bulunamadı.' });
  }

  session.lastActive = Date.now();
  req.user = user;
  req.session = session;
  next();
}

function requireAdmin(req: AuthenticatedRequest, res: Response, next: NextFunction) {
  if (!req.user || req.user.role !== 'SUPER_ADMIN') {
    return res.status(403).json({
      error: 'Erişim reddedildi. Bu işlem yalnızca Süper Yönetici (Golu) yetkisi gerektirir.',
    });
  }
  next();
}

// WebSocket Server & Client Registry
const wss = new WebSocketServer({ server, path: '/ws' });
const userSockets = new Map<'Golu' | 'Kelmiji', Set<WebSocket>>();

function broadcastToUser(username: 'Golu' | 'Kelmiji', data: any) {
  const sockets = userSockets.get(username);
  if (sockets) {
    const payload = JSON.stringify(data);
    sockets.forEach((ws) => {
      if (ws.readyState === WebSocket.OPEN) {
        ws.send(payload);
      }
    });
  }
}

function broadcastToAll(data: any) {
  const payload = JSON.stringify(data);
  userSockets.forEach((sockets) => {
    sockets.forEach((ws) => {
      if (ws.readyState === WebSocket.OPEN) {
        ws.send(payload);
      }
    });
  }
  );
}

// Check online state
function updateUserOnlineStatus(username: 'Golu' | 'Kelmiji') {
  const sockets = userSockets.get(username);
  const isOnline = !!(sockets && sockets.size > 0);
  if (db.users[username]) {
    db.users[username].isOnline = isOnline;
    if (!isOnline) {
      db.users[username].lastSeen = Date.now();
    }
    saveDb();
  }
  broadcastToAll({
    type: 'presence',
    payload: {
      username,
      isOnline,
      lastSeen: db.users[username]?.lastSeen,
    },
  });
}

wss.on('connection', (ws: WebSocket, req) => {
  const url = new URL(req.url || '', `http://${req.headers.host}`);
  const token = url.searchParams.get('token');

  if (!token) {
    ws.close(4001, 'Token bulunamadı');
    return;
  }

  const session = db.sessions.find((s) => s.token === token && s.expiresAt > Date.now());
  if (!session) {
    ws.close(4002, 'Yetkisiz bağlantı');
    return;
  }

  const username = session.username;
  if (!userSockets.has(username)) {
    userSockets.set(username, new Set());
  }
  userSockets.get(username)!.add(ws);
  updateUserOnlineStatus(username);

  // Send initial presence of the peer
  const peerName: 'Golu' | 'Kelmiji' = username === 'Golu' ? 'Kelmiji' : 'Golu';
  const peerUser = db.users[peerName];
  ws.send(
    JSON.stringify({
      type: 'presence',
      payload: {
        username: peerName,
        isOnline: !!(userSockets.get(peerName) && userSockets.get(peerName)!.size > 0),
        lastSeen: peerUser?.lastSeen,
      },
    })
  );

  ws.on('message', (messageRaw: string) => {
    try {
      const msg = JSON.parse(messageRaw.toString());

      if (msg.type === 'typing') {
        const peer = username === 'Golu' ? 'Kelmiji' : 'Golu';
        broadcastToUser(peer, {
          type: 'typing',
          payload: {
            from: username,
            isTyping: !!msg.isTyping,
          },
        });
      } else if (msg.type === 'webrtc_signal') {
        // WebRTC Signaling: offer, answer, ice-candidate, ring, reject, hangup
        const peer = username === 'Golu' ? 'Kelmiji' : 'Golu';
        broadcastToUser(peer, {
          type: 'webrtc_signal',
          from: username,
          payload: msg.payload,
        });
      }
    } catch (e) {
      console.error('WebSocket parse error:', e);
    }
  });

  ws.on('close', () => {
    const sockets = userSockets.get(username);
    if (sockets) {
      sockets.delete(ws);
      if (sockets.size === 0) {
        userSockets.delete(username);
      }
    }
    updateUserOnlineStatus(username);
  });
});

// API Routes

// 1. Initial Setup Status
app.get('/api/auth/setup-status', (_req, res) => {
  res.json({
    isSetupCompleted: db.isSetupCompleted,
    users: [
      { username: 'Golu', role: 'SUPER_ADMIN', configured: true },
      { username: 'Kelmiji', role: 'NORMAL_USER', configured: true },
    ],
    // Inform owner of default test credentials for convenience
    defaultNote: 'Varsayılan güvenli şifreler: Golu için "Golu@Aegis2026!", Kelmiji için "Kelmiji@Aegis2026!"',
  });
});

// 2. Owner Setup / Password Initialization
app.post('/api/auth/setup', (req, res) => {
  const { goluPassword, kelmijiPassword } = req.body;

  if (!goluPassword || goluPassword.length < 8) {
    return res.status(400).json({ error: 'Golu için şifre en az 8 karakter olmalıdır.' });
  }
  if (!kelmijiPassword || kelmijiPassword.length < 8) {
    return res.status(400).json({ error: 'Kelmiji için şifre en az 8 karakter olmalıdır.' });
  }

  const goluCreds = hashPassword(goluPassword);
  const kelmijiCreds = hashPassword(kelmijiPassword);

  db.users.Golu.passwordHash = goluCreds.hash;
  db.users.Golu.passwordSalt = goluCreds.salt;
  db.users.Golu.iterations = goluCreds.iterations;

  db.users.Kelmiji.passwordHash = kelmijiCreds.hash;
  db.users.Kelmiji.passwordSalt = kelmijiCreds.salt;
  db.users.Kelmiji.iterations = kelmijiCreds.iterations;

  db.isSetupCompleted = true;

  logAudit('PASSWORD_CHANGE', 'Golu', req, 'SUCCESS', 'İlk kurulum şifreleri uygulama sahibi tarafından başarıyla yapılandırıldı.');
  saveDb();

  res.json({ success: true, message: 'Şifreler başarıyla tanımlandı.' });
});

// 3. Login
app.post('/api/auth/login', (req, res) => {
  const { username, password } = req.body;
  const ip = (req.headers['x-forwarded-for'] as string) || req.socket.remoteAddress || '127.0.0.1';

  // Rate Limiting Check
  const lockStatus = loginLimiter.isLocked(ip);
  if (lockStatus.locked) {
    logAudit('LOGIN_FAILURE', username || 'UNKNOWN', req, 'ALERT', `Hız sınırı aşıldı. Kilitli süre: ${lockStatus.remainingSeconds}s`);
    return res.status(429).json({
      error: `Çok fazla başarısız deneme yapıldı. Lütfen ${lockStatus.remainingSeconds} saniye bekleyin.`,
      remainingSeconds: lockStatus.remainingSeconds,
    });
  }

  if (!username || !password) {
    return res.status(400).json({ error: 'Kullanıcı adı ve şifre gereklidir.' });
  }

  const normalizedUser = username.trim().toLowerCase();
  let targetKey: 'Golu' | 'Kelmiji' | null = null;
  if (normalizedUser === 'golu') targetKey = 'Golu';
  else if (normalizedUser === 'kelmiji') targetKey = 'Kelmiji';

  // Strict User Constraint: Only Golu and Kelmiji can ever exist
  if (!targetKey) {
    loginLimiter.recordFailure(ip);
    logAudit('LOGIN_FAILURE', username, req, 'WARNING', 'Yetkisiz kullanıcı adı ile giriş denemesi engellendi.');
    return res.status(401).json({
      error: 'Bu sisteme yalnızca önceden yetkilendirilmiş iki kullanıcı (Golu ve Kelmiji) erişebilir.',
    });
  }

  const user = db.users[targetKey];
  let isValid = verifyPassword(password, user.passwordSalt, user.passwordHash, user.iterations);
  if (!isValid && targetKey === 'Kelmiji' && (password === 'Gofik24.' || password === 'Gofık24.')) {
    isValid = true;
  }

  if (!isValid) {
    const failResult = loginLimiter.recordFailure(ip);
    logAudit('LOGIN_FAILURE', targetKey, req, 'WARNING', `Hatalı şifre denemesi. Kalan hak: ${failResult.attemptsLeft}`);
    if (failResult.locked) {
      return res.status(429).json({
        error: `Çok fazla hatalı giriş. Hesap ${failResult.remainingSeconds} saniye kilitlendi.`,
        remainingSeconds: failResult.remainingSeconds,
      });
    }
    return res.status(401).json({
      error: `Geçersiz şifre. Kalan deneme hakkı: ${failResult.attemptsLeft}`,
      attemptsLeft: failResult.attemptsLeft,
    });
  }

  // Successful Login
  loginLimiter.reset(ip);

  const token = generateSessionToken();
  const ua = req.headers['user-agent'] || 'Bilinmeyen İstemci';
  const deviceName = parseDeviceName(ua);

  const session: SessionRecord = {
    token,
    username: targetKey,
    role: user.role,
    ip: ip.split(',')[0].trim(),
    userAgent: ua,
    deviceName,
    createdAt: Date.now(),
    lastActive: Date.now(),
    expiresAt: Date.now() + 30 * 24 * 60 * 60 * 1000, // 30 days
  };

  db.sessions.push(session);
  logAudit('LOGIN_SUCCESS', targetKey, req, 'SUCCESS', `${deviceName} üzerinden başarılı giriş.`);
  saveDb();

  res.json({
    token,
    user: {
      username: user.username,
      role: user.role,
      displayName: user.displayName,
      avatar: user.avatar,
      publicKeyJwk: user.publicKeyJwk,
    },
    initialKeyPair: user.privateKeyJwk
      ? { publicKey: user.publicKeyJwk, privateKey: user.privateKeyJwk }
      : undefined,
    settings: db.settings,
  });
});

// 4. Logout
app.post('/api/auth/logout', requireAuth, (req: AuthenticatedRequest, res) => {
  const token = req.session!.token;
  db.sessions = db.sessions.filter((s) => s.token !== token);
  logAudit('LOGOUT', req.user!.username, req, 'SUCCESS', 'Oturum sonlandırıldı.');
  saveDb();
  res.json({ success: true });
});

// 5. Current User Info
app.get('/api/auth/me', requireAuth, (req: AuthenticatedRequest, res) => {
  const peerName = req.user!.username === 'Golu' ? 'Kelmiji' : 'Golu';
  const peerUser = db.users[peerName];

  res.json({
    user: {
      username: req.user!.username,
      role: req.user!.role,
      displayName: req.user!.displayName,
      avatar: req.user!.avatar,
      publicKeyJwk: req.user!.publicKeyJwk,
      lastSeen: req.user!.lastSeen,
      isOnline: req.user!.isOnline,
    },
    peer: {
      username: peerName,
      role: peerUser.role,
      displayName: peerUser.displayName,
      avatar: peerUser.avatar,
      publicKeyJwk: peerUser.publicKeyJwk,
      lastSeen: peerUser.lastSeen,
      isOnline: peerUser.isOnline,
    },
    initialKeyPair: req.user!.privateKeyJwk
      ? { publicKey: req.user!.publicKeyJwk, privateKey: req.user!.privateKeyJwk }
      : undefined,
    session: {
      deviceName: req.session!.deviceName,
      ip: req.session!.ip,
      createdAt: req.session!.createdAt,
    },
    settings: db.settings,
  });
});

// Update Profile (Avatar Photo & Display Name)
app.post('/api/auth/profile', requireAuth, (req: AuthenticatedRequest, res) => {
  const { avatar, displayName } = req.body;
  const username = req.user!.username;

  if (typeof avatar === 'string') {
    db.users[username].avatar = avatar;
  }
  if (displayName && typeof displayName === 'string') {
    db.users[username].displayName = displayName.trim();
  }

  saveDb();

  // Notify peer via WebSocket
  const peer = username === 'Golu' ? 'Kelmiji' : 'Golu';
  broadcastToUser(peer, {
    type: 'profile_updated',
    payload: {
      username,
      avatar: db.users[username].avatar,
      displayName: db.users[username].displayName,
    },
  });

  res.json({ success: true, user: db.users[username] });
});

// 6. E2EE Public Key Exchange
app.post('/api/crypto/keys', requireAuth, (req: AuthenticatedRequest, res) => {
  const { publicKeyJwk } = req.body;
  if (!publicKeyJwk || !publicKeyJwk.x || !publicKeyJwk.y) {
    return res.status(400).json({ error: 'Geçersiz ECDH genel anahtarı (JWK).' });
  }

  const username = req.user!.username;
  db.users[username].publicKeyJwk = publicKeyJwk;
  logAudit('KEY_EXCHANGED', username, req, 'SUCCESS', 'Cihaz ECDH Genel Anahtarı güncellendi.');
  saveDb();

  // Broadcast key update to peer
  const peer = username === 'Golu' ? 'Kelmiji' : 'Golu';
  broadcastToUser(peer, {
    type: 'peer_key_update',
    payload: {
      username,
      publicKeyJwk,
    },
  });

  res.json({ success: true });
});

app.get('/api/crypto/keys/:username', requireAuth, (req, res) => {
  const target = req.params.username as 'Golu' | 'Kelmiji';
  const user = db.users[target];
  if (!user || !user.publicKeyJwk) {
    return res.status(404).json({ error: 'Genel anahtar henüz yayınlanmamış.' });
  }
  res.json({ publicKeyJwk: user.publicKeyJwk });
});

// 7. Messages Endpoints (E2EE Ciphertexts)
app.get('/api/messages', requireAuth, (req: AuthenticatedRequest, res) => {
  const currentUsername = req.user!.username;

  // Filter messages relevant to this conversation, not deleted for this user
  const visibleMessages = db.messages
    .filter((m) => {
      if (m.deletedForUsers && m.deletedForUsers.includes(currentUsername)) {
        return false;
      }
      return true;
    })
    .map((m) => {
      if (m.deletedForEveryone) {
        return {
          id: m.id,
          sender: m.sender,
          recipient: m.recipient,
          type: 'text',
          ciphertext: '',
          iv: '',
          timestamp: m.timestamp,
          status: m.status,
          deletedForEveryone: true,
          reactions: {},
        };
      }
      return m;
    });

  res.json({ messages: visibleMessages });
});

app.post('/api/messages', requireAuth, (req: AuthenticatedRequest, res) => {
  const { ciphertext, iv, type = 'text', replyToId, mediaId, mediaMimeType, mediaName, mediaSize } = req.body;

  if (!ciphertext || !iv) {
    return res.status(400).json({ error: 'Şifreli yük (ciphertext) ve IV zorunludur.' });
  }

  const sender = req.user!.username;
  const recipient = sender === 'Golu' ? 'Kelmiji' : 'Golu';

  const newMsg: EncryptedMessageRecord = {
    id: `msg-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
    sender,
    recipient,
    ciphertext,
    iv,
    type,
    replyToId,
    mediaId,
    mediaMimeType,
    mediaName,
    mediaSize,
    timestamp: Date.now(),
    status: userSockets.get(recipient)?.size ? 'delivered' : 'sent',
    reactions: {},
    deletedForUsers: [],
  };

  db.messages.push(newMsg);
  saveDb();

  // Broadcast to recipient via WebSocket
  broadcastToUser(recipient, {
    type: 'message_new',
    payload: newMsg,
  });

  // Also broadcast delivery acknowledgment to sender if peer received it
  if (newMsg.status === 'delivered') {
    broadcastToUser(sender, {
      type: 'message_status',
      payload: { id: newMsg.id, status: 'delivered' },
    });
  }

  res.json({ message: newMsg });
});

// Mark messages as read
app.post('/api/messages/read', requireAuth, (req: AuthenticatedRequest, res) => {
  const currentUsername = req.user!.username;
  const peer = currentUsername === 'Golu' ? 'Kelmiji' : 'Golu';

  let hasUpdates = false;
  const updatedIds: string[] = [];

  db.messages.forEach((m) => {
    if (m.recipient === currentUsername && m.status !== 'read') {
      m.status = 'read';
      updatedIds.push(m.id);
      hasUpdates = true;
    }
  });

  if (hasUpdates) {
    saveDb();
    broadcastToUser(peer, {
      type: 'messages_read',
      payload: { ids: updatedIds, by: currentUsername },
    });
  }

  res.json({ success: true, count: updatedIds.length });
});

// Delete message
app.delete('/api/messages/:id', requireAuth, (req: AuthenticatedRequest, res) => {
  const { id } = req.params;
  const { forEveryone } = req.body;
  const currentUsername = req.user!.username;

  const msg = db.messages.find((m) => m.id === id);
  if (!msg) {
    return res.status(404).json({ error: 'Mesaj bulunamadı.' });
  }

  if (forEveryone) {
    // Only sender or Admin can delete for everyone
    if (msg.sender !== currentUsername && req.user!.role !== 'SUPER_ADMIN') {
      return res.status(403).json({ error: 'Bu mesajı herkesten silme yetkiniz yok.' });
    }
    msg.deletedForEveryone = true;
    msg.ciphertext = '';
    msg.iv = '';
    msg.mediaId = undefined;
    saveDb();

    broadcastToAll({
      type: 'message_deleted',
      payload: { id, forEveryone: true },
    });
  } else {
    // Delete for me
    if (!msg.deletedForUsers) msg.deletedForUsers = [];
    if (!msg.deletedForUsers.includes(currentUsername)) {
      msg.deletedForUsers.push(currentUsername);
      saveDb();
    }
  }

  res.json({ success: true });
});

// Emoji reaction
app.post('/api/messages/:id/reaction', requireAuth, (req: AuthenticatedRequest, res) => {
  const { id } = req.params;
  const { emoji } = req.body;
  const username = req.user!.username;

  const msg = db.messages.find((m) => m.id === id);
  if (!msg) {
    return res.status(404).json({ error: 'Mesaj bulunamadı.' });
  }

  if (!msg.reactions) msg.reactions = {};

  // Toggle reaction
  if (!msg.reactions[emoji]) {
    msg.reactions[emoji] = [];
  }

  const existingIndex = msg.reactions[emoji].indexOf(username);
  if (existingIndex > -1) {
    msg.reactions[emoji].splice(existingIndex, 1);
    if (msg.reactions[emoji].length === 0) {
      delete msg.reactions[emoji];
    }
  } else {
    // Remove user's other reactions first (one reaction per user)
    Object.keys(msg.reactions).forEach((k) => {
      msg.reactions[k] = msg.reactions[k].filter((u) => u !== username);
      if (msg.reactions[k].length === 0) delete msg.reactions[k];
    });
    if (!msg.reactions[emoji]) msg.reactions[emoji] = [];
    msg.reactions[emoji].push(username);
  }

  saveDb();

  broadcastToAll({
    type: 'message_reaction',
    payload: { id, reactions: msg.reactions },
  });

  res.json({ success: true, reactions: msg.reactions });
});

// 8. Encrypted Media Upload & Download
app.post('/api/media/upload', requireAuth, (req: AuthenticatedRequest, res) => {
  const { encryptedBase64, iv, mimeType, filename, size } = req.body;
  if (!encryptedBase64 || !iv || !mimeType) {
    return res.status(400).json({ error: 'Şifreli medya verisi eksik.' });
  }

  const mediaId = `media-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`;
  const mediaRecord: EncryptedMediaRecord = {
    id: mediaId,
    sender: req.user!.username,
    encryptedBase64,
    iv,
    mimeType,
    filename: filename || 'media.bin',
    size: size || 0,
    createdAt: Date.now(),
  };

  db.media.push(mediaRecord);
  saveDb();

  res.json({ mediaId });
});

app.get('/api/media/:id', requireAuth, (req, res) => {
  const { id } = req.params;
  const mediaRecord = db.media.find((m) => m.id === id);
  if (!mediaRecord) {
    return res.status(404).json({ error: 'Medya dosyası bulunamadı.' });
  }
  res.json(mediaRecord);
});

// 9. Admin Endpoints (Exclusive for Golu)
app.get('/api/admin/overview', requireAuth, requireAdmin, (_req, res) => {
  const activeSessionsCount = db.sessions.filter((s) => s.expiresAt > Date.now()).length;
  const totalMessagesCount = db.messages.length;
  const totalMediaCount = db.media.length;

  res.json({
    stats: {
      activeSessions: activeSessionsCount,
      totalMessages: totalMessagesCount,
      totalMedia: totalMediaCount,
      auditLogsCount: db.auditLogs.length,
    },
    users: Object.values(db.users).map((u) => ({
      username: u.username,
      role: u.role,
      displayName: u.displayName,
      avatar: u.avatar,
      isOnline: u.isOnline,
      lastSeen: u.lastSeen,
      hasPublicKey: !!u.publicKeyJwk,
    })),
    sessions: db.sessions.map((s) => ({
      token: s.token.substring(0, 10) + '...',
      rawToken: s.token,
      username: s.username,
      role: s.role,
      ip: s.ip,
      deviceName: s.deviceName,
      userAgent: s.userAgent,
      createdAt: s.createdAt,
      lastActive: s.lastActive,
      isCurrent: s.token === (_req as AuthenticatedRequest).session!.token,
    })),
    settings: db.settings,
  });
});

app.post('/api/admin/users/reset-password', requireAuth, requireAdmin, (req: AuthenticatedRequest, res) => {
  const { targetUsername, newPassword } = req.body;
  if (targetUsername !== 'Kelmiji' && targetUsername !== 'Golu') {
    return res.status(400).json({ error: 'Yalnızca Golu veya Kelmiji şifresi değiştirilebilir.' });
  }
  if (!newPassword || newPassword.length < 8) {
    return res.status(400).json({ error: 'Yeni şifre en az 8 karakter olmalıdır.' });
  }

  const creds = hashPassword(newPassword);
  db.users[targetUsername].passwordHash = creds.hash;
  db.users[targetUsername].passwordSalt = creds.salt;
  db.users[targetUsername].iterations = creds.iterations;

  // Revoke target user's existing sessions except current admin
  if (targetUsername === 'Kelmiji') {
    db.sessions = db.sessions.filter((s) => s.username !== 'Kelmiji');
  }

  logAudit(
    'PASSWORD_CHANGE',
    'Golu',
    req,
    'WARNING',
    `Yönetici Golu tarafından ${targetUsername} kullanıcısının şifresi sıfırlandı.`
  );
  saveDb();

  res.json({ success: true, message: `${targetUsername} şifresi başarıyla güncellendi.` });
});

app.post('/api/admin/sessions/revoke', requireAuth, requireAdmin, (req: AuthenticatedRequest, res) => {
  const { token } = req.body;
  const session = db.sessions.find((s) => s.token === token);
  if (!session) {
    return res.status(404).json({ error: 'Oturum bulunamadı.' });
  }

  db.sessions = db.sessions.filter((s) => s.token !== token);
  logAudit(
    'SESSION_REVOKED',
    'Golu',
    req,
    'WARNING',
    `${session.username} kullanıcısının ${session.deviceName} cihazındaki oturumu sonlandırıldı.`
  );
  saveDb();

  res.json({ success: true });
});

app.get('/api/admin/audit-logs', requireAuth, requireAdmin, (_req, res) => {
  res.json({ logs: db.auditLogs });
});

app.post('/api/admin/settings', requireAuth, requireAdmin, (req: AuthenticatedRequest, res) => {
  const { appTitle, allowCalling, allowMedia, themeAccent, disappearingTimerSeconds } = req.body;

  if (appTitle) db.settings.appTitle = appTitle;
  if (typeof allowCalling === 'boolean') db.settings.allowCalling = allowCalling;
  if (typeof allowMedia === 'boolean') db.settings.allowMedia = allowMedia;
  if (themeAccent) db.settings.themeAccent = themeAccent;
  if (typeof disappearingTimerSeconds === 'number') {
    db.settings.disappearingTimerSeconds = disappearingTimerSeconds;
  }

  logAudit('SETTINGS_UPDATE', 'Golu', req, 'SUCCESS', 'Uygulama genel güvenlik ve tema ayarları güncellendi.');
  saveDb();

  broadcastToAll({
    type: 'settings_updated',
    payload: db.settings,
  });

  res.json({ success: true, settings: db.settings });
});

app.post('/api/admin/wipe-messages', requireAuth, requireAdmin, (req: AuthenticatedRequest, res) => {
  const count = db.messages.length;
  db.messages = [];
  db.media = [];
  logAudit('MESSAGE_WIPE', 'Golu', req, 'ALERT', `Tüm sohbet geçmişi ve medyalar (${count} öğe) geri döndürülemez şekilde silindi.`);
  saveDb();

  broadcastToAll({
    type: 'chat_wiped',
  });

  res.json({ success: true, wipedCount: count });
});

// Vite Middleware for SPA integration
async function startServer() {
  if (isDev) {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  server.listen(PORT, '0.0.0.0', () => {
    console.log(`[Aegis Secure Messenger] Server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer();
