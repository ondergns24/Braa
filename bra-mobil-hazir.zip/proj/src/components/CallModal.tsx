import React, { useRef, useEffect, useState } from 'react';
import {
  Phone,
  PhoneOff,
  Mic,
  MicOff,
  Video,
  VideoOff,
  RefreshCw,
  ShieldCheck,
  Volume2,
} from 'lucide-react';
import { webrtc } from '../services/webrtc';
import { CallState, Username } from '../types';

interface CallModalProps {
  callState: CallState;
  onAcceptCall: () => void;
  onRejectCall: () => void;
  onEndCall: () => void;
}

export function CallModal({
  callState,
  onAcceptCall,
  onRejectCall,
  onEndCall,
}: CallModalProps) {
  const localVideoRef = useRef<HTMLVideoElement>(null);
  const remoteVideoRef = useRef<HTMLVideoElement>(null);

  const [callDuration, setCallDuration] = useState(0);
  const [isMuted, setIsMuted] = useState(callState.isMuted);
  const [isCameraOff, setIsCameraOff] = useState(callState.isCameraOff);
  const [facingMode, setFacingMode] = useState<'user' | 'environment'>('user');

  // Track call duration when connected
  useEffect(() => {
    if (callState.status !== 'connected') {
      setCallDuration(0);
      return;
    }
    const interval = setInterval(() => {
      setCallDuration((prev) => prev + 1);
    }, 1000);
    return () => clearInterval(interval);
  }, [callState.status]);

  // Hook up video streams
  useEffect(() => {
    const localStream = webrtc.getLocalStream();
    if (localVideoRef.current && localStream) {
      localVideoRef.current.srcObject = localStream;
    }

    const remoteStream = webrtc.getRemoteStream();
    if (remoteVideoRef.current && remoteStream) {
      remoteVideoRef.current.srcObject = remoteStream;
    }
  }, [callState.status]);

  const handleToggleMute = () => {
    const muted = webrtc.toggleMute();
    setIsMuted(muted);
  };

  const handleToggleCamera = () => {
    const camOff = webrtc.toggleCamera();
    setIsCameraOff(camOff);
  };

  const handleFlipCamera = async () => {
    const newFacing = await webrtc.flipCamera();
    setFacingMode(newFacing);
  };

  const formatTimer = (sec: number) => {
    const m = Math.floor(sec / 60);
    const s = sec % 60;
    return `${m < 10 ? '0' : ''}${m}:${s < 10 ? '0' : ''}${s}`;
  };

  if (!callState.isActive) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/90 backdrop-blur-md animate-in fade-in duration-200">
      {/* Full Screen Video / Audio Overlay */}
      <div className="relative w-full h-full max-w-4xl max-h-[95vh] bg-[#0d121a] sm:rounded-3xl border border-slate-800 shadow-2xl overflow-hidden flex flex-col justify-between p-6">
        {/* Top Header: Peer & Security info */}
        <div className="relative z-20 flex items-center justify-between w-full">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-teal-500/20 border border-teal-500/40 flex items-center justify-center font-bold text-teal-300 text-base">
              {callState.peer.charAt(0).toUpperCase()}
            </div>
            <div>
              <h3 className="text-base font-bold text-white leading-tight">
                {callState.peer} ile {callState.type === 'video' ? 'Görüntülü' : 'Sesli'} Arama
              </h3>
              <div className="flex items-center gap-2 mt-0.5">
                <span className="inline-flex items-center gap-1 text-[11px] font-medium text-teal-400 bg-teal-500/10 px-2 py-0.5 rounded-full border border-teal-500/30">
                  <ShieldCheck className="w-3 h-3" /> Uçtan Uca Şifreli WebRTC P2P
                </span>
                {callState.status === 'connected' && (
                  <span className="text-xs font-mono text-slate-300 bg-slate-800/80 px-2 py-0.5 rounded-full border border-slate-700">
                    {formatTimer(callDuration)}
                  </span>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Center Area: Video streams or Voice Audio Avatar */}
        <div className="relative flex-1 my-6 flex items-center justify-center overflow-hidden rounded-2xl bg-[#090c10] border border-slate-800/60">
          {callState.type === 'video' ? (
            <>
              {/* Remote Video Stream */}
              <video
                ref={remoteVideoRef}
                autoPlay
                playsInline
                className="w-full h-full object-cover"
              />

              {/* Local Video Stream (PiP thumbnail) */}
              <div className="absolute bottom-4 right-4 w-32 h-44 sm:w-40 sm:h-56 rounded-2xl overflow-hidden border-2 border-slate-700 shadow-2xl bg-slate-900 z-10">
                <video
                  ref={localVideoRef}
                  autoPlay
                  playsInline
                  muted
                  className={`w-full h-full object-cover ${isCameraOff ? 'hidden' : ''}`}
                />
                {isCameraOff && (
                  <div className="w-full h-full flex flex-col items-center justify-center text-slate-500 text-xs gap-1">
                    <VideoOff className="w-6 h-6" />
                    <span>Kamera Kapalı</span>
                  </div>
                )}
              </div>
            </>
          ) : (
            // Voice Call Mode Avatar & Audio Waves
            <div className="flex flex-col items-center justify-center text-center p-8">
              <div className="relative mb-6">
                <div
                  className={`w-24 h-24 rounded-full bg-slate-800 border-2 border-teal-500/40 flex items-center justify-center text-3xl font-extrabold text-teal-300 shadow-xl ${
                    callState.status === 'connected' ? 'animate-pulse' : ''
                  }`}
                >
                  {callState.peer.charAt(0).toUpperCase()}
                </div>
                {callState.status === 'connected' && (
                  <div className="absolute -inset-2 rounded-full border border-teal-400/40 animate-ping pointer-events-none" />
                )}
              </div>

              <h4 className="text-xl font-bold text-white mb-1">{callState.peer}</h4>
              <p className="text-xs text-slate-400">
                {callState.status === 'calling' && 'Aranıyor... (Zil Çalıyor)'}
                {callState.status === 'ringing' && 'Gelen Arama...'}
                {callState.status === 'connected' && 'Sesli Arama Bağlandı'}
                {callState.status === 'ended' && 'Arama Sonlandı'}
              </p>
            </div>
          )}
        </div>

        {/* Bottom Control Bar */}
        <div className="relative z-20 flex items-center justify-center gap-4">
          {callState.status === 'ringing' && callState.isIncoming ? (
            // Incoming Call: Accept (Green) or Reject (Red)
            <div className="flex items-center gap-6 animate-bounce">
              <button
                type="button"
                onClick={onRejectCall}
                className="flex flex-col items-center gap-1.5"
              >
                <div className="w-14 h-14 rounded-full bg-red-600 hover:bg-red-500 text-white flex items-center justify-center shadow-lg shadow-red-600/30 transition-all active:scale-95">
                  <PhoneOff className="w-6 h-6" />
                </div>
                <span className="text-xs text-slate-300 font-medium">Reddet</span>
              </button>

              <button
                type="button"
                onClick={onAcceptCall}
                className="flex flex-col items-center gap-1.5"
              >
                <div className="w-14 h-14 rounded-full bg-emerald-500 hover:bg-emerald-400 text-slate-950 flex items-center justify-center shadow-lg shadow-emerald-500/30 transition-all active:scale-95">
                  <Phone className="w-6 h-6" />
                </div>
                <span className="text-xs text-emerald-300 font-semibold">Kabul Et</span>
              </button>
            </div>
          ) : (
            // Active / Outgoing Call Controls
            <div className="flex items-center gap-3 sm:gap-4 bg-[#141b26] border border-slate-800 p-2.5 rounded-2xl shadow-xl">
              {/* Mute Mic */}
              <button
                type="button"
                onClick={handleToggleMute}
                className={`p-3 rounded-xl transition-all ${
                  isMuted
                    ? 'bg-red-500/20 text-red-300 border border-red-500/30'
                    : 'bg-slate-800 text-slate-200 hover:bg-slate-700'
                }`}
                title={isMuted ? 'Mikrofonu Aç' : 'Mikrofonu Kapat'}
              >
                {isMuted ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
              </button>

              {/* Video Camera Toggle (If Video Call) */}
              {callState.type === 'video' && (
                <>
                  <button
                    type="button"
                    onClick={handleToggleCamera}
                    className={`p-3 rounded-xl transition-all ${
                      isCameraOff
                        ? 'bg-red-500/20 text-red-300 border border-red-500/30'
                        : 'bg-slate-800 text-slate-200 hover:bg-slate-700'
                    }`}
                    title={isCameraOff ? 'Kamerayı Aç' : 'Kamerayı Kapat'}
                  >
                    {isCameraOff ? <VideoOff className="w-5 h-5" /> : <Video className="w-5 h-5" />}
                  </button>

                  <button
                    type="button"
                    onClick={handleFlipCamera}
                    className="p-3 rounded-xl bg-slate-800 text-slate-200 hover:bg-slate-700 transition-all"
                    title="Ön/Arka Kamera Değiştir"
                  >
                    <RefreshCw className="w-5 h-5" />
                  </button>
                </>
              )}

              {/* Hang Up (Red) */}
              <button
                type="button"
                onClick={onEndCall}
                className="px-5 py-3 rounded-xl bg-red-600 hover:bg-red-500 text-white font-semibold flex items-center gap-2 shadow-lg shadow-red-600/30 active:scale-95 transition-all"
                title="Aramayı Sonlandır"
              >
                <PhoneOff className="w-5 h-5" />
                <span className="text-xs">Kapat</span>
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
