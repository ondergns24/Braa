import crypto from 'node:crypto';

export interface UserCredentials {
  salt: string;
  hash: string;
  iterations: number;
}

/**
 * Hashes password securely using PBKDF2 with SHA-512 and 100,000 iterations.
 */
export function hashPassword(password: string, customSalt?: string): UserCredentials {
  const salt = customSalt || crypto.randomBytes(32).toString('hex');
  const iterations = 100_000;
  const hash = crypto.pbkdf2Sync(password, salt, iterations, 64, 'sha512').toString('hex');
  return { salt, hash, iterations };
}

/**
 * Validates password against stored salt and hash using timing-safe comparison.
 */
export function verifyPassword(password: string, storedSalt: string, storedHash: string, iterations = 100_000): boolean {
  try {
    const testHash = crypto.pbkdf2Sync(password, storedSalt, iterations, 64, 'sha512').toString('hex');
    const bufA = Buffer.from(testHash, 'hex');
    const bufB = Buffer.from(storedHash, 'hex');
    if (bufA.length !== bufB.length) return false;
    return crypto.timingSafeEqual(bufA, bufB);
  } catch {
    return false;
  }
}

/**
 * Generates initial P-256 ECDH keypair in JWK format for Signal identity provisioning.
 */
export function generateEcKeyPairJwk(): { publicKey: any; privateKey: any } {
  const { publicKey, privateKey } = crypto.generateKeyPairSync('ec', {
    namedCurve: 'prime256v1',
  });
  return {
    publicKey: publicKey.export({ format: 'jwk' }),
    privateKey: privateKey.export({ format: 'jwk' }),
  };
}

/**
 * Generates high-entropy session token.
 */
export function generateSessionToken(): string {
  return crypto.randomBytes(32).toString('hex');
}

/**
 * Rate limiter state tracking
 */
export class RateLimiter {
  private attempts = new Map<string, { count: number; lockedUntil: number }>();
  private readonly maxAttempts: number;
  private readonly windowMs: number;
  private readonly lockoutMs: number;

  constructor(maxAttempts = 5, windowMs = 15 * 60 * 1000, lockoutMs = 15 * 60 * 1000) {
    this.maxAttempts = maxAttempts;
    this.windowMs = windowMs;
    this.lockoutMs = lockoutMs;
  }

  isLocked(key: string): { locked: boolean; remainingSeconds?: number } {
    const record = this.attempts.get(key);
    if (!record) return { locked: false };
    const now = Date.now();
    if (record.lockedUntil > now) {
      return {
        locked: true,
        remainingSeconds: Math.ceil((record.lockedUntil - now) / 1000),
      };
    }
    return { locked: false };
  }

  recordFailure(key: string): { locked: boolean; attemptsLeft: number; remainingSeconds?: number } {
    const now = Date.now();
    let record = this.attempts.get(key);
    if (!record) {
      record = { count: 1, lockedUntil: 0 };
    } else if (record.lockedUntil > 0 && record.lockedUntil <= now) {
      record = { count: 1, lockedUntil: 0 };
    } else {
      record.count += 1;
    }

    if (record.count >= this.maxAttempts) {
      record.lockedUntil = now + this.lockoutMs;
      this.attempts.set(key, record);
      return {
        locked: true,
        attemptsLeft: 0,
        remainingSeconds: Math.ceil(this.lockoutMs / 1000),
      };
    }

    this.attempts.set(key, record);
    return {
      locked: false,
      attemptsLeft: this.maxAttempts - record.count,
    };
  }

  reset(key: string): void {
    this.attempts.delete(key);
  }
}
