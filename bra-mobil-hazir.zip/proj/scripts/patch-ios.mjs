// `npx cap add ios` sonrası çalışır: Info.plist'e kamera/mikrofon açıklamalarını ekler.
import fs from 'node:fs';

const file = 'ios/App/App/Info.plist';
let plist = fs.readFileSync(file, 'utf8');

const entries = {
  NSCameraUsageDescription: 'Görüntülü arama ve fotoğraf/video göndermek için kamera gerekir.',
  NSMicrophoneUsageDescription: 'Sesli/görüntülü arama ve sesli mesaj için mikrofon gerekir.',
  NSPhotoLibraryUsageDescription: 'Galerinizden fotoğraf ve video seçip göndermek için gerekir.',
  ITSAppUsesNonExemptEncryption: false,
};

let add = '';
for (const [k, v] of Object.entries(entries)) {
  if (plist.includes(`<key>${k}</key>`)) continue;
  add += `\t<key>${k}</key>\n` + (typeof v === 'boolean' ? `\t<${v}/>\n` : `\t<string>${v}</string>\n`);
}
if (add) {
  const i = plist.lastIndexOf('</dict>');
  plist = plist.slice(0, i) + add + plist.slice(i);
}
fs.writeFileSync(file, plist);
console.log('iOS Info.plist güncellendi.');
