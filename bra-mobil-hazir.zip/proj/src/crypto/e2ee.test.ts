import test from 'node:test';
import assert from 'node:assert/strict';
import {
  generateDeviceKeyPair,
  deriveSharedSecretKey,
  encryptObject,
  decryptObject,
  encryptBinary,
  decryptBinary,
} from './e2ee';

test('E2EE ECDH Key exchange and AES-256-GCM encryption between Golu and Kelmiji', async () => {
  // Golu generates keypair
  const goluKeys = await generateDeviceKeyPair();
  assert.ok(goluKeys.publicKey.x, 'Golu public key should have curve coordinates');
  assert.ok(goluKeys.privateKey.d, 'Golu private key should have private parameter');

  // Kelmiji generates keypair
  const kelmijiKeys = await generateDeviceKeyPair();
  assert.ok(kelmijiKeys.publicKey.x, 'Kelmiji public key should have curve coordinates');

  // Golu derives shared key using Kelmiji's public key
  const goluSharedKey = await deriveSharedSecretKey(goluKeys.privateKey, kelmijiKeys.publicKey);

  // Kelmiji derives shared key using Golu's public key
  const kelmijiSharedKey = await deriveSharedSecretKey(kelmijiKeys.privateKey, goluKeys.publicKey);

  assert.ok(goluSharedKey, 'Golu shared key should be generated');
  assert.ok(kelmijiSharedKey, 'Kelmiji shared key should be generated');

  // Golu encrypts a message
  const secretMessage = {
    text: 'Merhaba Kelmiji, bu mesaj uçtan uca şifrelidir!',
    timestamp: Date.now(),
    type: 'text',
  };

  const encryptedPayload = await encryptObject(secretMessage, goluSharedKey);
  assert.ok(encryptedPayload.ciphertext, 'Ciphertext should be non-empty base64');
  assert.ok(encryptedPayload.iv, 'IV should be non-empty base64');
  assert.notEqual(encryptedPayload.ciphertext, secretMessage.text, 'Plaintext should not appear in ciphertext');

  // Kelmiji decrypts the message
  const decrypted = await decryptObject<typeof secretMessage>(encryptedPayload, kelmijiSharedKey);
  assert.equal(decrypted.text, secretMessage.text);
  assert.equal(decrypted.timestamp, secretMessage.timestamp);
  assert.equal(decrypted.type, 'text');

  // Test binary encryption (e.g. voice note audio or photo bytes)
  const dummyAudio = new Uint8Array([10, 20, 30, 40, 50, 60, 70, 80]).buffer;
  const encryptedMedia = await encryptBinary(dummyAudio, kelmijiSharedKey);
  assert.ok(encryptedMedia.iv);
  assert.notEqual(encryptedMedia.encryptedBuffer.byteLength, 0);

  // Golu decrypts binary media
  const decryptedBlob = await decryptBinary(
    encryptedMedia.encryptedBuffer,
    encryptedMedia.iv,
    goluSharedKey,
    'audio/webm'
  );
  assert.equal(decryptedBlob.type, 'audio/webm');
  assert.equal(decryptedBlob.size, 8);
});
