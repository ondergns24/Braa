import React, { useState, useEffect } from 'react';
import {
  X,
  Sliders,
  Users,
  ShieldAlert,
  Smartphone,
  Palette,
  Trash2,
  KeyRound,
  CheckCircle,
  AlertTriangle,
  RefreshCw,
  LogOut,
  Clock,
  Eye,
  EyeOff,
} from 'lucide-react';
import { api } from '../services/api';
import { AppSettings, AuditLog, ActiveSession } from '../types';

interface AdminPanelProps {
  onClose: () => void;
  onSettingsUpdated: (settings: AppSettings) => void;
}

export function AdminPanel({ onClose, onSettingsUpdated }: AdminPanelProps) {
  const [activeTab, setActiveTab] = useState<
    'overview' | 'users' | 'sessions' | 'logs' | 'settings' | 'danger'
  >('overview');

  const [loading, setLoading] = useState(true);
  const [overviewData, setOverviewData] = useState<any>(null);
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  // User Password Reset states
  const [resetTargetUser, setResetTargetUser] = useState<'Kelmiji' | 'Golu'>('Kelmiji');
  const [newPasswordInput, setNewPasswordInput] = useState('');
  const [resetLoading, setResetLoading] = useState(false);

  // Settings states
  const [appTitle, setAppTitle] = useState('');
  const [disappearingTimer, setDisappearingTimer] = useState(0);
  const [allowCalling, setAllowCalling] = useState(true);
  const [allowMedia, setAllowMedia] = useState(true);
  const [themeAccent, setThemeAccent] = useState('teal');
  const [savingSettings, setSavingSettings] = useState(false);

  // Wipe confirmation
  const [wipeConfirmText, setWipeConfirmText] = useState('');
  const [wipeLoading, setWipeLoading] = useState(false);

  const fetchOverview = async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await api.getAdminOverview();
      setOverviewData(data);
      if (data.settings) {
        setAppTitle(data.settings.appTitle || 'Özel Uçtan Uca Şifreli Mesajlaşma');
        setDisappearingTimer(data.settings.disappearingTimerSeconds || 0);
        setAllowCalling(data.settings.allowCalling ?? true);
        setAllowMedia(data.settings.allowMedia ?? true);
        setThemeAccent(data.settings.themeAccent || 'teal');
      }
    } catch (err: any) {
      setError(err.message || 'Yönetici verileri yüklenemedi.');
    } finally {
      setLoading(false);
    }
  };

  const fetchLogs = async () => {
    try {
      const data = await api.getAdminAuditLogs();
      setAuditLogs(data.logs || []);
    } catch (err: any) {
      console.warn('Logs error:', err);
    }
  };

  useEffect(() => {
    fetchOverview();
    fetchLogs();
  }, []);

  const handleResetPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (newPasswordInput.length < 8) {
      setError('Yeni şifre en az 8 karakter olmalıdır.');
      return;
    }

    setResetLoading(true);
    setError(null);
    setSuccessMsg(null);

    try {
      const res = await api.adminResetPassword(resetTargetUser, newPasswordInput);
      setSuccessMsg(res.message || 'Şifre başarıyla güncellendi.');
      setNewPasswordInput('');
      fetchOverview();
      fetchLogs();
    } catch (err: any) {
      setError(err.message || 'Şifre sıfırlanamadı.');
    } finally {
      setResetLoading(false);
    }
  };

  const handleRevokeSession = async (sessionId: string) => {
    if (!confirm('Bu oturumu ve cihaz erişimini sonlandırmak istediğinizden emin misiniz?')) {
      return;
    }
    try {
      await api.adminRevokeSession(sessionId);
      setSuccessMsg('Oturum başarıyla sonlandırıldı.');
      fetchOverview();
      fetchLogs();
    } catch (err: any) {
      setError(err.message || 'Oturum sonlandırılamadı.');
    }
  };

  const handleSaveSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    setSavingSettings(true);
    setError(null);
    setSuccessMsg(null);

    try {
      const res = await api.updateSettings({
        appTitle,
        disappearingTimerSeconds: Number(disappearingTimer),
        allowCalling,
        allowMedia,
        themeAccent,
      });
      setSuccessMsg('Uygulama ve güvenlik ayarları güncellendi.');
      onSettingsUpdated(res.settings);
    } catch (err: any) {
      setError(err.message || 'Ayarlar kaydedilemedi.');
    } finally {
      setSavingSettings(false);
    }
  };

  const handleWipeData = async () => {
    if (wipeConfirmText !== 'TÜM VERİLERİ SİL') {
      setError('Lütfen onay kutusuna "TÜM VERİLERİ SİL" yazın.');
      return;
    }

    setWipeLoading(true);
    setError(null);
    try {
      const res = await api.wipeMessages();
      setSuccessMsg(`Tüm mesajlar ve medyalar silindi (${res.wipedCount} kayıt).`);
      setWipeConfirmText('');
      fetchOverview();
      fetchLogs();
    } catch (err: any) {
      setError(err.message || 'Veri silinemedi.');
    } finally {
      setWipeLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/85 backdrop-blur-md animate-in fade-in duration-200">
      <div className="w-full max-w-4xl h-[92vh] bg-[#121722] border border-slate-800 rounded-3xl shadow-2xl flex flex-col overflow-hidden">
        {/* Modal Header */}
        <div className="p-4 sm:p-5 border-b border-slate-800 bg-[#0e131c] flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-amber-500 to-teal-500 p-0.5 flex items-center justify-center shadow-lg">
              <div className="w-full h-full bg-[#0d121a] rounded-[10px] flex items-center justify-center">
                <Sliders className="w-5 h-5 text-amber-400" />
              </div>
            </div>
            <div>
              <h2 className="text-base font-bold text-white flex items-center gap-2">
                Süper Yönetici Kontrol Paneli
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30">
                  Golu Özel
                </span>
              </h2>
              <p className="text-xs text-slate-400">
                Kullanıcı yetkileri, güvenlik oturumları, denetim kayıtları ve sistem ayarları.
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Status Alerts */}
        {error && (
          <div className="mx-4 mt-3 p-3 rounded-xl bg-red-500/15 border border-red-500/30 text-red-300 text-xs flex items-center justify-between">
            <span className="flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-red-400 shrink-0" />
              {error}
            </span>
            <button onClick={() => setError(null)} className="text-red-400 hover:text-white">
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        )}

        {successMsg && (
          <div className="mx-4 mt-3 p-3 rounded-xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 text-xs flex items-center justify-between">
            <span className="flex items-center gap-2">
              <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0" />
              {successMsg}
            </span>
            <button onClick={() => setSuccessMsg(null)} className="text-emerald-400 hover:text-white">
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        )}

        {/* Tab Navigation */}
        <div className="flex items-center gap-1 px-4 sm:px-6 pt-3 border-b border-slate-800 bg-[#0e131c]/50 overflow-x-auto shrink-0">
          {[
            { id: 'overview', label: 'Genel Bakış', icon: Sliders },
            { id: 'users', label: 'Kullanıcı Yönetimi', icon: Users },
            { id: 'sessions', label: 'Cihaz & Oturumlar', icon: Smartphone },
            { id: 'logs', label: 'Denetim Günlüğü', icon: ShieldAlert },
            { id: 'settings', label: 'Ayarlar & Tema', icon: Palette },
            { id: 'danger', label: 'Veri İmhası', icon: Trash2 },
          ].map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                type="button"
                onClick={() => {
                  setActiveTab(tab.id as any);
                  setError(null);
                  setSuccessMsg(null);
                }}
                className={`flex items-center gap-2 px-3.5 py-2.5 border-b-2 text-xs font-semibold whitespace-nowrap transition-all ${
                  isActive
                    ? 'border-teal-400 text-teal-300 bg-teal-500/10 rounded-t-lg'
                    : 'border-transparent text-slate-400 hover:text-slate-200'
                }`}
              >
                <Icon className="w-4 h-4" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>

        {/* Tab Body */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 bg-[#0b0f16]">
          {loading ? (
            <div className="flex items-center justify-center h-48 text-slate-400 text-xs gap-2">
              <RefreshCw className="w-4 h-4 animate-spin text-teal-400" />
              <span>Yönetim verileri getiriliyor...</span>
            </div>
          ) : (
            <>
              {/* TAB 1: OVERVIEW */}
              {activeTab === 'overview' && overviewData && (
                <div className="space-y-6">
                  {/* Metric Cards */}
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 sm:gap-4">
                    <div className="p-4 rounded-2xl bg-[#141b26] border border-slate-800">
                      <div className="text-slate-400 text-xs font-medium">Aktif Oturumlar</div>
                      <div className="text-2xl font-bold text-white mt-1">
                        {overviewData.stats.activeSessions}
                      </div>
                      <div className="text-[10px] text-teal-400 mt-1">Yetkili Cihazlar</div>
                    </div>

                    <div className="p-4 rounded-2xl bg-[#141b26] border border-slate-800">
                      <div className="text-slate-400 text-xs font-medium">Toplam Mesajlar</div>
                      <div className="text-2xl font-bold text-white mt-1">
                        {overviewData.stats.totalMessages}
                      </div>
                      <div className="text-[10px] text-teal-400 mt-1">Uçtan Uca Şifreli</div>
                    </div>

                    <div className="p-4 rounded-2xl bg-[#141b26] border border-slate-800">
                      <div className="text-slate-400 text-xs font-medium">Medya Dosyaları</div>
                      <div className="text-2xl font-bold text-white mt-1">
                        {overviewData.stats.totalMedia}
                      </div>
                      <div className="text-[10px] text-teal-400 mt-1">AES-256 Şifreli</div>
                    </div>

                    <div className="p-4 rounded-2xl bg-[#141b26] border border-slate-800">
                      <div className="text-slate-400 text-xs font-medium">Güvenlik Kayıtları</div>
                      <div className="text-2xl font-bold text-white mt-1">
                        {overviewData.stats.auditLogsCount}
                      </div>
                      <div className="text-[10px] text-teal-400 mt-1">Denetim Günlüğü</div>
                    </div>
                  </div>

                  {/* Registered Users Summary */}
                  <div className="p-5 rounded-2xl bg-[#141b26] border border-slate-800">
                    <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider mb-3">
                      Sistem Kullanıcıları (Yalnızca 2 Kişilik Kapalı Mimari)
                    </h3>
                    <div className="space-y-3">
                      {overviewData.users.map((u: any) => (
                        <div
                          key={u.username}
                          className="flex items-center justify-between p-3 rounded-xl bg-[#0e131d] border border-slate-800"
                        >
                          <div className="flex items-center gap-3">
                            <div className="w-9 h-9 rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center font-bold text-teal-400 text-sm overflow-hidden shrink-0">
                              {u.avatar ? (
                                <img src={u.avatar} alt={u.username} className="w-full h-full object-cover" />
                              ) : (
                                u.username.charAt(0).toUpperCase()
                              )}
                            </div>
                            <div>
                              <div className="text-sm font-semibold text-white flex items-center gap-2">
                                {u.displayName || u.username}
                                <span
                                  className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                                    u.role === 'SUPER_ADMIN'
                                      ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                                      : 'bg-teal-500/20 text-teal-300 border border-teal-500/30'
                                  }`}
                                >
                                  {u.role === 'SUPER_ADMIN' ? 'SÜPER YÖNETİCİ' : 'NORMAL KULLANICI'}
                                </span>
                              </div>
                              <div className="text-xs text-slate-400 mt-0.5">
                                ECDH Anahtarı:{' '}
                                {u.hasPublicKey ? (
                                  <span className="text-emerald-400">Yayınlandı (P-256)</span>
                                ) : (
                                  <span className="text-amber-400">Bekleniyor</span>
                                )}
                              </div>
                            </div>
                          </div>

                          <div className="text-right">
                            <span className="inline-block px-2.5 py-1 rounded-full text-xs font-medium bg-teal-500/15 border border-teal-500/30 text-teal-300">
                              {u.role === 'SUPER_ADMIN' ? 'Süper Yönetici' : 'Kullanıcı'}
                            </span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 2: USER MANAGEMENT */}
              {activeTab === 'users' && (
                <div className="space-y-6">
                  <div className="p-5 rounded-2xl bg-[#141b26] border border-slate-800">
                    <h3 className="text-sm font-bold text-white flex items-center gap-2 mb-2">
                      <KeyRound className="w-4 h-4 text-teal-400" />
                      Kullanıcı Şifresi Sıfırla (Kelmiji veya Golu)
                    </h3>
                    <p className="text-xs text-slate-400 mb-4">
                      Süper yönetici olarak Kelmiji kullanıcısının parolasını doğrudan sıfırlayabilirsiniz.
                      Şifre güncellendiğinde Kelmiji'nin diğer tüm cihaz oturumları otomatik olarak kapatılır.
                    </p>

                    <form onSubmit={handleResetPassword} className="space-y-4 max-w-md">
                      <div>
                        <label className="block text-xs font-medium text-slate-400 mb-1.5">
                          Hedef Kullanıcı
                        </label>
                        <select
                          value={resetTargetUser}
                          onChange={(e) => setResetTargetUser(e.target.value as any)}
                          className="w-full px-3.5 py-2.5 bg-[#0e131d] border border-slate-700 rounded-xl text-xs text-white focus:outline-none focus:ring-1 focus:ring-teal-500"
                        >
                          <option value="Kelmiji">Kelmiji (Normal Kullanıcı)</option>
                          <option value="Golu">Golu (Süper Yönetici)</option>
                        </select>
                      </div>

                      <div>
                        <label className="block text-xs font-medium text-slate-400 mb-1.5">
                          Yeni Güvenli Parola (En az 8 Karakter)
                        </label>
                        <input
                          type="password"
                          value={newPasswordInput}
                          onChange={(e) => setNewPasswordInput(e.target.value)}
                          placeholder="Yeni şifreyi girin..."
                          required
                          minLength={8}
                          className="w-full px-3.5 py-2.5 bg-[#0e131d] border border-slate-700 rounded-xl text-xs text-white focus:outline-none focus:ring-1 focus:ring-teal-500"
                        />
                      </div>

                      <button
                        type="submit"
                        disabled={resetLoading}
                        className="px-4 py-2.5 bg-teal-500 hover:bg-teal-400 text-slate-950 font-bold text-xs rounded-xl shadow-md transition-colors disabled:opacity-50"
                      >
                        {resetLoading ? 'Güncelleniyor...' : 'Şifreyi Değiştir ve Oturumları Yenile'}
                      </button>
                    </form>
                  </div>
                </div>
              )}

              {/* TAB 3: SESSIONS & DEVICES */}
              {activeTab === 'sessions' && overviewData && (
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider">
                      Aktif Cihazlar & Oturumlar
                    </h3>
                    <button
                      type="button"
                      onClick={fetchOverview}
                      className="text-xs text-teal-400 hover:text-teal-300 flex items-center gap-1"
                    >
                      <RefreshCw className="w-3.5 h-3.5" /> Yenile
                    </button>
                  </div>

                  <div className="space-y-3">
                    {overviewData.sessions.map((s: any) => (
                      <div
                        key={s.id}
                        className={`p-4 rounded-2xl border transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-3 ${
                          s.isCurrent
                            ? 'bg-teal-500/10 border-teal-500/40'
                            : 'bg-[#141b26] border-slate-800'
                        }`}
                      >
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded-xl bg-slate-800 flex items-center justify-center text-teal-300">
                            <Smartphone className="w-5 h-5" />
                          </div>
                          <div>
                            <div className="text-sm font-semibold text-white flex items-center gap-2">
                              {s.deviceName}
                              {s.isCurrent && (
                                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-teal-500 text-slate-950">
                                  BU CİHAZ
                                </span>
                              )}
                            </div>
                            <div className="text-xs text-slate-400 mt-0.5">
                              Kullanıcı: <strong className="text-slate-200">{s.username}</strong> | IP: {s.ip}
                            </div>
                            <div className="text-[11px] text-slate-500 mt-0.5">
                              Giriş: {new Date(s.createdAt).toLocaleString()} | Son Etkinlik:{' '}
                              {new Date(s.lastActive).toLocaleTimeString()}
                            </div>
                          </div>
                        </div>

                        {!s.isCurrent && (
                          <button
                            type="button"
                            onClick={() => handleRevokeSession(s.id)}
                            className="px-3 py-1.5 rounded-xl bg-red-500/20 hover:bg-red-500/30 text-red-300 text-xs font-medium border border-red-500/40 flex items-center gap-1.5 self-start sm:self-center transition-colors"
                          >
                            <LogOut className="w-3.5 h-3.5" /> Oturumu Sonlandır
                          </button>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* TAB 4: AUDIT LOGS */}
              {activeTab === 'logs' && (
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider">
                      Güvenlik ve Giriş Denetim Kayıtları
                    </h3>
                    <button
                      type="button"
                      onClick={fetchLogs}
                      className="text-xs text-teal-400 hover:text-teal-300 flex items-center gap-1"
                    >
                      <RefreshCw className="w-3.5 h-3.5" /> Yenile
                    </button>
                  </div>

                  <div className="bg-[#141b26] border border-slate-800 rounded-2xl overflow-hidden">
                    <div className="overflow-x-auto">
                      <table className="w-full text-left text-xs">
                        <thead className="bg-[#0e131d] text-slate-400 border-b border-slate-800">
                          <tr>
                            <th className="p-3">Zaman</th>
                            <th className="p-3">Olay</th>
                            <th className="p-3">Kullanıcı</th>
                            <th className="p-3">IP Adresi</th>
                            <th className="p-3">Durum</th>
                            <th className="p-3">Ayrıntılar</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-800 text-slate-300">
                          {auditLogs.map((log) => (
                            <tr key={log.id} className="hover:bg-slate-800/40 transition-colors">
                              <td className="p-3 whitespace-nowrap text-slate-400">
                                {new Date(log.timestamp).toLocaleTimeString()} -{' '}
                                {new Date(log.timestamp).toLocaleDateString()}
                              </td>
                              <td className="p-3 font-semibold text-white whitespace-nowrap">
                                {log.event}
                              </td>
                              <td className="p-3 font-medium text-teal-300">{log.username}</td>
                              <td className="p-3 font-mono text-slate-400">{log.ip}</td>
                              <td className="p-3 whitespace-nowrap">
                                <span
                                  className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                                    log.status === 'SUCCESS'
                                      ? 'bg-emerald-500/20 text-emerald-300'
                                      : log.status === 'WARNING'
                                      ? 'bg-amber-500/20 text-amber-300'
                                      : 'bg-red-500/20 text-red-300'
                                  }`}
                                >
                                  {log.status}
                                </span>
                              </td>
                              <td className="p-3 text-slate-300 min-w-48">{log.details}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 5: SETTINGS & APPEARANCE */}
              {activeTab === 'settings' && (
                <div className="space-y-6 max-w-xl">
                  <form onSubmit={handleSaveSettings} className="space-y-4">
                    <div>
                      <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                        Uygulama Başlığı
                      </label>
                      <input
                        type="text"
                        value={appTitle}
                        onChange={(e) => setAppTitle(e.target.value)}
                        className="w-full px-3.5 py-2.5 bg-[#141b26] border border-slate-700 rounded-xl text-xs text-white focus:outline-none focus:ring-1 focus:ring-teal-500"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                        Kaybolan Mesajlar Süresi
                      </label>
                      <select
                        value={disappearingTimer}
                        onChange={(e) => setDisappearingTimer(Number(e.target.value))}
                        className="w-full px-3.5 py-2.5 bg-[#141b26] border border-slate-700 rounded-xl text-xs text-white focus:outline-none focus:ring-1 focus:ring-teal-500"
                      >
                        <option value={0}>Devre Dışı (Süresiz Saklama)</option>
                        <option value={3600}>1 Saat Sonra Silinsin</option>
                        <option value={86400}>24 Saat Sonra Silinsin</option>
                        <option value={604800}>7 Gün Sonra Silinsin</option>
                      </select>
                    </div>

                    <div className="flex items-center justify-between p-3.5 rounded-xl bg-[#141b26] border border-slate-800">
                      <div>
                        <div className="text-xs font-semibold text-white">Sesli ve Görüntülü Arama</div>
                        <div className="text-[11px] text-slate-400">WebRTC P2P aramalarına izin ver</div>
                      </div>
                      <input
                        type="checkbox"
                        checked={allowCalling}
                        onChange={(e) => setAllowCalling(e.target.checked)}
                        className="w-4 h-4 text-teal-500 rounded bg-slate-900 border-slate-700 focus:ring-teal-500"
                      />
                    </div>

                    <div className="flex items-center justify-between p-3.5 rounded-xl bg-[#141b26] border border-slate-800">
                      <div>
                        <div className="text-xs font-semibold text-white">Medya ve Belge Gönderimi</div>
                        <div className="text-[11px] text-slate-400">Fotoğraf, video ve sesli mesajlara izin ver</div>
                      </div>
                      <input
                        type="checkbox"
                        checked={allowMedia}
                        onChange={(e) => setAllowMedia(e.target.checked)}
                        className="w-4 h-4 text-teal-500 rounded bg-slate-900 border-slate-700 focus:ring-teal-500"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
                        Tema Vurgu Rengi
                      </label>
                      <div className="grid grid-cols-4 gap-2">
                        {[
                          { id: 'teal', label: 'Signal Turkuaz', color: 'bg-teal-500' },
                          { id: 'emerald', label: 'Zümrüt Yeşil', color: 'bg-emerald-500' },
                          { id: 'cyan', label: 'Siber Mavi', color: 'bg-cyan-500' },
                          { id: 'indigo', label: 'Gece Mavisi', color: 'bg-indigo-500' },
                        ].map((theme) => (
                          <button
                            key={theme.id}
                            type="button"
                            onClick={() => setThemeAccent(theme.id)}
                            className={`p-3 rounded-xl border flex flex-col items-center gap-1 text-xs transition-all ${
                              themeAccent === theme.id
                                ? 'border-teal-400 bg-teal-500/15 text-white'
                                : 'border-slate-800 bg-[#141b26] text-slate-400 hover:text-white'
                            }`}
                          >
                            <span className={`w-4 h-4 rounded-full ${theme.color}`} />
                            <span className="text-[11px]">{theme.label}</span>
                          </button>
                        ))}
                      </div>
                    </div>

                    <button
                      type="submit"
                      disabled={savingSettings}
                      className="px-5 py-2.5 bg-teal-500 hover:bg-teal-400 text-slate-950 font-bold text-xs rounded-xl shadow-md transition-colors"
                    >
                      {savingSettings ? 'Kaydediliyor...' : 'Ayarları Kaydet'}
                    </button>
                  </form>
                </div>
              )}

              {/* TAB 6: DANGER ZONE & REMOTE WIPE */}
              {activeTab === 'danger' && (
                <div className="p-6 rounded-2xl bg-red-950/20 border border-red-500/30 space-y-4 max-w-xl">
                  <div className="flex items-center gap-3 text-red-400">
                    <Trash2 className="w-6 h-6" />
                    <h3 className="text-base font-bold text-white">Acil Durum: Sohbeti ve Medyaları Tamamen Sil</h3>
                  </div>
                  <p className="text-xs text-red-200/80 leading-relaxed">
                    Bu işlem sunucudaki ve veritabanındaki tüm şifreli mesajları, fotoğrafları, videoları ve ses kayıtlarını
                    geri döndürülemez şekilde tamamen yok eder. Bu işlem geri alınamaz.
                  </p>

                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                      Onaylamak için <strong className="text-red-400">TÜM VERİLERİ SİL</strong> yazın:
                    </label>
                    <input
                      type="text"
                      value={wipeConfirmText}
                      onChange={(e) => setWipeConfirmText(e.target.value)}
                      placeholder="TÜM VERİLERİ SİL"
                      className="w-full px-3.5 py-2.5 bg-[#0e131d] border border-red-500/40 rounded-xl text-xs text-white focus:outline-none focus:ring-1 focus:ring-red-500"
                    />
                  </div>

                  <button
                    type="button"
                    onClick={handleWipeData}
                    disabled={wipeConfirmText !== 'TÜM VERİLERİ SİL' || wipeLoading}
                    className="px-5 py-2.5 bg-red-600 hover:bg-red-500 text-white font-bold text-xs rounded-xl shadow-md transition-colors disabled:opacity-40 disabled:cursor-not-allowed"
                  >
                    {wipeLoading ? 'Siliniyor...' : 'Sohbet Geçmişini Geri Dönüşsüz İmha Et'}
                  </button>
                </div>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
}
