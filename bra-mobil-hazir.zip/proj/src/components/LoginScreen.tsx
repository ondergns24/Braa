import React, { useState, useEffect } from 'react';
import { Eye, EyeOff, ArrowRight } from 'lucide-react';
import { api, setStoredToken } from '../services/api';
import loginBg from '../assets/images/user_login_bg.jpg';

interface LoginScreenProps {
  onLoginSuccess: (data: { token: string; user: any; settings: any }) => void;
}

export function LoginScreen({ onLoginSuccess }: LoginScreenProps) {
  const [username, setUsername] = useState('Golu');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [lockoutTimer, setLockoutTimer] = useState<number | null>(null);

  useEffect(() => {
    if (!lockoutTimer || lockoutTimer <= 0) return;
    const interval = setInterval(() => {
      setLockoutTimer((prev) => {
        if (!prev || prev <= 1) {
          setError(null);
          return null;
        }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(interval);
  }, [lockoutTimer]);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!password || !username) {
      return;
    }

    setLoading(true);
    setError(null);

    try {
      const res = await api.login(username.trim(), password);
      setStoredToken(res.token);
      onLoginSuccess(res);
    } catch (err: any) {
      setError(err.message || '');
      if (err.remainingSeconds) {
        setLockoutTimer(err.remainingSeconds);
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div
      className="min-h-dvh w-full flex items-center justify-center p-4 bg-cover bg-center relative select-none"
      style={{ backgroundImage: `url(${loginBg})` }}
    >
      {/* Subtle Dark Overlay for high photo visibility and contrast */}
      <div className="absolute inset-0 bg-black/45" />

      <div className="relative z-10 w-full max-w-xs sm:max-w-sm flex flex-col items-center">
        {/* Only "Bra" */}
        <h1 className="text-4xl sm:text-5xl font-extrabold text-white tracking-widest uppercase mb-10 drop-shadow-md">
          Bra
        </h1>

        {/* Error notification if any */}
        {error && (
          <div className="w-full mb-4 px-3.5 py-2.5 rounded-xl bg-red-500/20 border border-red-500/40 text-red-200 text-xs text-center backdrop-blur-md">
            {error} {lockoutTimer ? `(${lockoutTimer}s)` : ''}
          </div>
        )}

        {/* Login Form: Minimal Inputs without text */}
        <form onSubmit={handleLogin} className="w-full space-y-3.5">
          {/* Username Selector / Input */}
          <div className="grid grid-cols-2 gap-2 p-1 bg-black/60 border border-white/10 rounded-2xl backdrop-blur-md">
            <button
              type="button"
              onClick={() => {
                setUsername('Golu');
                setError(null);
              }}
              className={`py-2.5 rounded-xl text-xs font-semibold tracking-wider transition-all cursor-pointer ${
                username === 'Golu'
                  ? 'bg-white/15 text-white border border-white/20 shadow-sm'
                  : 'text-neutral-400 hover:text-white'
              }`}
            >
              Golu
            </button>
            <button
              type="button"
              onClick={() => {
                setUsername('Kelmiji');
                setError(null);
              }}
              className={`py-2.5 rounded-xl text-xs font-semibold tracking-wider transition-all cursor-pointer ${
                username === 'Kelmiji'
                  ? 'bg-white/15 text-white border border-white/20 shadow-sm'
                  : 'text-neutral-400 hover:text-white'
              }`}
            >
              Kelmiji
            </button>
          </div>

          {/* Password Input: Clean empty placeholder */}
          <div className="relative">
            <input
              type={showPassword ? 'text' : 'password'}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder=""
              autoFocus
              disabled={loading || !!lockoutTimer}
              className="w-full px-4 py-3.5 bg-black/60 border border-white/10 rounded-2xl text-white text-sm focus:outline-none focus:border-teal-500/80 focus:ring-1 focus:ring-teal-500/50 backdrop-blur-md transition-all tracking-wider"
            />
            <button
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              aria-label={showPassword ? 'Gizle' : 'Göster'}
              className="absolute inset-y-0 right-0 pr-3.5 flex items-center text-neutral-400 hover:text-white transition-colors"
            >
              {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
            </button>
          </div>

          {/* Minimal Login Button */}
          <button
            type="submit"
            disabled={loading || !!lockoutTimer}
            className="w-full py-3.5 px-4 bg-teal-500 hover:bg-teal-400 active:scale-[0.98] text-slate-950 font-bold rounded-2xl text-sm transition-all flex items-center justify-center gap-2 shadow-lg shadow-teal-500/20 cursor-pointer disabled:opacity-50"
          >
            {loading ? (
              <div className="w-4 h-4 border-2 border-slate-950 border-t-transparent rounded-full animate-spin" />
            ) : (
              <ArrowRight className="w-5 h-5" />
            )}
          </button>
        </form>
      </div>
    </div>
  );
}
