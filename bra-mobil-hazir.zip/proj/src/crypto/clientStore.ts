import {
  generateDeviceKeyPair,
  deriveSharedSecretKey,
  encryptObject,
  decryptObject,
  encryptBinary,
  decryptBinary,
  base64ToBuffer,
  bufferToBase64,
  KeyPairJwk,
} from './e2ee';
import { api } from '../services/api';
import { Username } from '../types';

interface StoredKeys {
  username: Username;
  keyPair: KeyPairJwk;
}

class ClientCryptoManager {
  private currentUsername: Username | null = null;
  private localKeyPair: KeyPairJwk | null = null;
  private peerPublicKey: JsonWebKey | null = null;
  private sharedSecretKey: CryptoKey | null = null;

  async initializeUser(username: Username, serverProvidedKeys?: KeyPairJwk): Promise<void> {
    this.currentUsername = username;
    const storageKey = `aegis_keys_${username}`;
    const stored = localStorage.getItem(storageKey);

    if (stored) {
      try {
        const parsed: StoredKeys = JSON.parse(stored);
        this.localKeyPair = parsed.keyPair;
      } catch {
        this.localKeyPair = null;
      }
    }

    if (!this.localKeyPair) {
      if (serverProvidedKeys?.publicKey && serverProvidedKeys?.privateKey) {
        this.localKeyPair = serverProvidedKeys;
      } else {
        // Generate fresh ECDH P-256 keypair for this device
        this.localKeyPair = await generateDeviceKeyPair();
      }
      localStorage.setItem(storageKey, JSON.stringify({ username, keyPair: this.localKeyPair }));
    }

    // Publish public key to server so peer can derive shared secret
    try {
      await api.publishPublicKey(this.localKeyPair.publicKey);
    } catch (err) {
      console.warn('Failed to publish public key immediately:', err);
    }
  }

  async setPeerPublicKey(peerPublicKey: JsonWebKey): Promise<void> {
    if (!peerPublicKey || !this.localKeyPair) return;
    this.peerPublicKey = peerPublicKey;
    this.sharedSecretKey = await deriveSharedSecretKey(this.localKeyPair.privateKey, peerPublicKey);
  }

  hasSharedKey(): boolean {
    return !!this.sharedSecretKey;
  }

  async encryptMessagePayload(payload: any): Promise<{ ciphertext: string; iv: string }> {
    if (!this.sharedSecretKey) {
      throw new Error('E2EE Ortak Şifreleme Anahtarı henüz kurulmadı. Karşı tarafın anahtarı bekleniyor.');
    }
    return await encryptObject(payload, this.sharedSecretKey);
  }

  async decryptMessagePayload<T>(ciphertext: string, iv: string): Promise<T> {
    if (!this.sharedSecretKey) {
      throw new Error('E2EE Ortak Şifreleme Anahtarı mevcut değil.');
    }
    return await decryptObject<T>({ ciphertext, iv }, this.sharedSecretKey);
  }

  async encryptMediaFile(fileBuffer: ArrayBuffer): Promise<{ encryptedBase64: string; iv: string }> {
    if (!this.sharedSecretKey) {
      throw new Error('E2EE Ortak Şifreleme Anahtarı mevcut değil.');
    }
    const { encryptedBuffer, iv } = await encryptBinary(fileBuffer, this.sharedSecretKey);
    return {
      encryptedBase64: bufferToBase64(encryptedBuffer),
      iv,
    };
  }

  async decryptMediaFile(encryptedBase64: string, iv: string, mimeType: string): Promise<Blob> {
    if (!this.sharedSecretKey) {
      throw new Error('E2EE Ortak Şifreleme Anahtarı mevcut değil.');
    }
    const encryptedBuffer = base64ToBuffer(encryptedBase64).buffer as ArrayBuffer;
    return await decryptBinary(encryptedBuffer, iv, this.sharedSecretKey, mimeType);
  }

  /**
   * Generates a 60-digit safety number (12 blocks of 5 digits) for out-of-band verification
   * exactly like Signal's Safety Number verification.
   */
  async computeSafetyNumber(): Promise<string> {
    if (!this.localKeyPair || !this.peerPublicKey) {
      return '00000 00000 00000 00000 00000 00000 00000 00000 00000 00000 00000 00000';
    }

    // Combine both public keys deterministically in sorted order
    const keys = [
      JSON.stringify(this.localKeyPair.publicKey),
      JSON.stringify(this.peerPublicKey),
    ].sort();

    const combinedStr = keys.join(':');
    const encoder = new TextEncoder();
    const hashBuffer = await crypto.subtle.digest('SHA-512', encoder.encode(combinedStr));
    const hashBytes = new Uint8Array(hashBuffer);

    // Format into 12 chunks of 5-digit numbers
    const blocks: string[] = [];
    for (let i = 0; i < 12; i++) {
      const offset = i * 4;
      const num =
        ((hashBytes[offset] << 24) |
          (hashBytes[offset + 1] << 16) |
          (hashBytes[offset + 2] << 8) |
          hashBytes[offset + 3]) >>>
        0;
      const fiveDigit = (num % 100000).toString().padStart(5, '0');
      blocks.push(fiveDigit);
    }

    return blocks.join(' ');
  }
}

export const cryptoManager = new ClientCryptoManager();
