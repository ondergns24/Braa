# Bra — iki kişilik şifreli mesajlaşma (Web + Android APK + iOS)

React + Vite arayüzü, Express + WebSocket sunucusu, WebRTC aramaları. Mobil paketleme: Capacitor.

## Mimari (önemli)
Mobil uygulama yalnızca arayüzdür; **sunucu internette bir yerde çalışmak zorundadır**.
Telefon uygulaması derleme sırasında verilen `VITE_API_URL` adresine bağlanır.

## 1) Sunucuyu yayına al
Docker destekleyen herhangi bir yer (Render, Fly.io, Railway, VPS...):

```bash
docker build -t bra .
docker run -d -p 3000:3000 -v bra-data:/data \
  -e GOLU_PASSWORD='güçlü-bir-şifre' -e KELMIJI_PASSWORD='başka-güçlü-şifre' bra
```
- HTTPS **şarttır** (kamera/mikrofon ve iOS için). Genelde barındırma sağlayıcısı verir.
- `/data` kalıcı disk olmalı; olmazsa her yeniden başlatmada mesajlar silinir.
- Şifre vermezseniz rastgele üretilir ve ilk açılışta log'a bir kez yazılır.

## 2) Android APK (bilgisayarsız, GitHub ile)
1. Projeyi bir **özel (private)** GitHub deposuna yükleyin.
2. Depo → Settings → Secrets and variables → Actions → **Variables** → `VITE_API_URL` = sunucu adresiniz (örn. `https://bra.ornek.com`, sonunda `/` yok).
3. Actions sekmesi → **Android APK** → Run workflow.
4. Bitince çıkan **Bra-android-apk** dosyasını indirin, içindeki `app-debug.apk`'yı telefona atıp açın ("bilinmeyen kaynaklara izin ver").

Kendi bilgisayarınızda: `npm install && npm run build && npx cap add android && node scripts/patch-android.mjs && npx cap sync android` sonra `npx cap open android` (Android Studio).

## 3) iOS
iOS'ta imzasız uygulama telefona yüklenemez. Seçenekler:
- **Ücretsiz, en kolay:** Sunucu HTTPS'te çalışırken iPhone Safari'de siteyi açın → Paylaş → *Ana Ekrana Ekle* (PWA).
- **Gerçek uygulama:** Mac + Xcode + Apple kimliği (ücretsiz imza 7 gün geçerli) veya Apple Developer hesabı (yıllık ücretli, TestFlight/App Store).
  `iOS Build` iş akışı projeyi macOS'ta derleyip Xcode'da açabileceğiniz `ios-project.zip` üretir.

## Geliştirme
```bash
cp .env.example .env.local   # gerekirse
npm install
npm run dev                  # http://localhost:3000
npm test
```

## Güvenlik notları
- Şifreler artık kodda değil, ortam değişkenlerinde. Eski sürümde kodda yazılı olan şifreler ifşa olduğu için **değiştirin**.
- Özel anahtarlar sunucuda tutulmaz; her cihaz kendi anahtarını üretir. Yeni cihaz/yeniden kurulumda yeni anahtar oluşur ve **eski mesajlar o cihazda çözülemez**.
- Sunucu karşı tarafın genel anahtarını değiştirebilir; ortadaki adam riskine karşı Güvenlik ekranındaki **güvenlik numarasını** karşılıklı doğrulayın.
- Anahtar sabit (ECDH) olduğundan Signal'deki gibi ileri gizlilik (forward secrecy) yoktur.
